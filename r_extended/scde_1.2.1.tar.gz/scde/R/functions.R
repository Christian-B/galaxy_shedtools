##' Single-cell Differential Expression
##'
##' SCDE implements routines for analysis single-cell RNA-seq data, including fitting of error models and testing of differential expression.
##' Please see vignette("diffexp") for a brief tutorial.
##' More extensive tutorials are available at \url{http://pklab.med.harvard.edu/scde/index.html}.
##' 
##' @name scde
##' @docType package
##' @author Peter Kharchenko \email{peter.kharchenko@@post.harvard.edu}
NULL


##' Sample data
##' 
##' A subset of Saiful et al. 2011 dataset containing first 20 ES and 20 MEF cells.
##' @name es.mef.small
##' @docType data
##' @references \url{http://www.ncbi.nlm.nih.gov/pubmed/21543516}
##' @export
NULL


##' Fit single-cell error/regression models
##'
##' Fit error models given a set of single-cell data (counts) and an optional grouping factor (groups). The cells (within each group) are first cross-compared to determine a subset of genes showing consistent expression. The set of genes is then used to fit a mixture model (Poisson-NB mixture, with expression-dependent concomitant). 
##' @param counts read count matrix. The rows correspond to genes (should be named), columns correspond to individual cells. The matrix should contain integer counts 
##' @param groups an optional factor describing grouping of different cells. If provided, the cross-fits and the expected expression magnitudes will be determined separately within each group. The factor should have the same length as ncol(counts).
##' @param min.nonfailed minimal number of non-failed observations required for a gene to be used in the final model fitting;
##' @param threshold.segmentation use a fast threshold-based segmentation during cross-fit (default: T)
##' @param min.count.threshold the number of reads to use to guess which genes may have "failed" to be detected in a given measurement during cross-cell comparison (default 4 reads)
##' @param zero.count.threshold threshold to guess the initial value (failed/non-failed) during error model fitting procedure (defaults to the min.count.threshold value)
##' @param zero.lambda the rate of the Poisson (failure) component (default : 0.1)
##' @param save.crossfit.plots whether png files showing cross-fit segmentations should be written out (default: F)
##' @param save.model.plots whether pdf files showing model fits should be written out (default=T)
##' @param n.cores number of cores to use
##' @param min.size.entries minimum number of genes to use when determining expected expression magnitude during model fitting
##' @param max.pairs maximum number of cross-fit comparisons that should be performed per group (default 5000)
##' @param min.pairs.per.cell minimum number of pairs that each cell should be cross-compared with
##' @param verbose 1 for increased output
##' @return a model matrix, with rows corresponding to different cells, and columns representing different parameters of the determined models
##' @useDynLib scde
##' @return a data frame containing model parameters
##' @export
scde.error.models <- function(counts,groups=NULL,min.nonfailed=3,threshold.segmentation=T,min.count.threshold=4,zero.count.threshold=min.count.threshold,zero.lambda=0.1,save.crossfit.plots=F,save.model.plots=T,n.cores=12,min.size.entries=2e3,max.pairs=5000,min.pairs.per.cell=10,verbose=0) {
  if(is.null(groups)) {
    groups <- as.factor(rep("cell",ncol(counts)));
  }
  # crossfit
  if(verbose) {
    cat("cross-fitting cells.\n");
  }
  cfm <- calculate.crossfit.models(counts,groups,n.cores=n.cores,threshold.segmentation=threshold.segmentation,min.count.threshold=min.count.threshold,zero.lambda=zero.lambda,max.pairs=max.pairs,save.plots=save.crossfit.plots,min.pairs.per.cell=min.pairs.per.cell)
  if(verbose) {
    cat("building individual error models.\n");
  }
  ifm <- calculate.individual.models(counts,groups,cfm,min.nonfailed=min.nonfailed,zero.count.threshold=zero.count.threshold,n.cores=n.cores,save.plots=save.model.plots,old.fit=T,return.compressed.models=T,verbose=verbose,min.size.entries=min.size.entries);
  rm(cfm); gc();
  return(ifm);
}

##' Estimate prior distribution for gene expression magnitudes
##'
##' Use existing count data to determine a prior distribution of genes in the dataset
##' @param models models determiend by \code{\link{scde.error.models}}
##' @param counts count matrix
##' @param length.out number of points (resolution) of the expression magnitude grid (default: 400). Note: larger numbers will linearly increase memory/CPU demands.
##' @param show.plot show the estimate posterior
##' @param pseudo.count pseudo-count value to use (default 1)
##' @param bw smoothing bandwidth to use in estimating the prior (default: 0.1)
##' @param max.quantile determine the maximum expression magnitude based on a quantile (default : 0.999)
##' @param max.value alternatively, specify the exact maximum expression magntiude value
##' @return a structure describing expression magnitude grid ($x, on log10 scale) and prior ($y)
##' @export
scde.expression.prior <- function(models,counts,length.out=400,show.plot=F,pseudo.count=1,bw=0.1,max.quantile=0.999,max.value=NULL) {
  fpkm <- scde.expression.magnitude(models,counts);
  fail <- scde.failure.probability(models,counts=counts)
  fpkm <- log10(exp(as.matrix(fpkm))+1);
  wts <- as.numeric(as.matrix(1-fail[,colnames(fpkm)]))
  wts <- wts/sum(wts);

  # fit density on a mirror image
  if(is.null(max.value)) {
    x <- as.numeric(fpkm);
    max.value <- as.numeric(quantile(x[x<Inf],p=max.quantile));
  }
  md <- density(c(-1*as.numeric(fpkm),as.numeric(fpkm)),bw=bw,weights=c(wts/2,wts/2),n=2*length.out+1,from=-1*max.value,to=max.value)
  
  gep <- data.frame(x=md$x[-c(1:length.out)],y=md$y[-c(1:length.out)])
  gep$y[is.na(gep$y)] <- 0;
  gep$y <- gep$y+pseudo.count/nrow(fpkm); # pseudo-count
  gep$y <- gep$y/sum(gep$y)
  if(show.plot) {
    par(mfrow=c(1,1),mar = c(3.5,3.5,3.5,0.5), mgp = c(2.0,0.65,0), cex = 0.9);
    plot(gep$x,gep$y,col=4,panel.first=abline(h=0,lty=2),type='l',xlab="log10( signal+1 )",ylab="probability density",main="signal prior")
  }
  gep$lp <- log(gep$y);

  # grid weighting (for normalization)
  gep$grid.weight <- diff(10^c(gep$x[1],gep$x+c(diff(gep$x)/2,0))-1);
  
  return(gep);
  plot(x)
}


##' Test for expression differences between two sets of cells
##'
##' Use the individual cell error models to test for differential expression between two groups of cells.
##' @param models models determiend by \code{\link{scde.error.models}}
##' @param counts read count matrix
##' @param prior gene expression prior as determiend by \code{\link{scde.expression.prior}}
##' @param groups a factor determining the two groups of cells being compared. The factor entries should correspond to the rows of the model matrix. The factor should have two levels. NAs are allowed (cells will be omitted from comparison).
##' @param batch a factor (corresponding to rows of the model matrix) specifying batch assignment of each cell, to perform batch correction
##' @param n.randomizations number of bootstrap randomizations to be performed
##' @param n.cores number of cores to utilize
##' @param batch.models (optional) separate models for the batch data (if generated using batch-specific group argument). Normally the same models are used.
##' @param return.posteriors whether joint posterior matrices should be returned
##' @param verbose integer verbose level (1 for verbose)
##' @return \subsection{default}{
##' a data frame with the following fields:
##' \itemize{
##' \item{lb, mle, ub} {lower bound, maximum likelihood estimate, and upper bound of the 95% confidence interval for the expression fold change on log2 scale.} 
##' \item{ce} { conservative estimate of expression-fold change (equals to the min(abs(c(lb,ub))), or 0 if the CI crosses the 0}
##' \item{Z} { uncorrected Z-score of expression difference}
##' \item{cZ} {expression difference Z-score corrected for multiple hypothesis testing using Holm procedure}
##' }
##'  If batch correction has been performed (\code{batch} has been supplied), analogous data frames are returned in slots \code{$batch.adjusted} for batch-corrected results, and \code{$batch.effect} for the differences explained by batch effects alone.
##' }}
##' \subsection{return.posteriors=T}{
##' A list is returned, with the default results data frame given in the \code{$resutls} slot.
##' \code{difference.posterior} returns a matrix of estimated expression difference posteriors (rows - genes, columns correspond to different magnitudes of fold-change - log2 values are given in the column names)
##' \code{joint.posteriors} a list of two joint posterior matrices (rows - genes, columns correspond to the expression levels, given by prior$x grid)
##' }
##' 
##' 
##' @export
scde.expression.difference <- function(models,counts,prior,groups=NULL,batch=NULL,n.randomizations=150,n.cores=10,batch.models=models,return.posteriors=F,verbose=0) {
  if(!all(rownames(models) %in% colnames(counts))) { stop("ERROR: provided count data does not cover all of the cells specified in the model matrix") }
  ci <- match(rownames(models),colnames(counts))
  counts <- as.matrix(counts[,ci]);
  
  if(is.null(groups)) { # recover groups from models
    groups <- as.factor(attr(models,"groups"));
    if(is.null(groups)) stop("ERROR: groups factor is not provided, and models structure is lacking groups attribute");
    names(groups) <- rownames(models)
  }
  if(length(levels(groups))!=2) {
    stop(paste("ERROR: wrong number of levels in the grouping factor (",paste(levels(groups),collapse=" "),"), but must be two.",sep=""))
  }

  correct.batch <- F;
  if(!is.null(batch)) {
    if(length(levels(batch))>1) {
      correct.batch <- T;
    } else {
      if(verbose) {
        cat("WARNING: only one batch level detected. Nothing to correct for.")
      }
    }
  }
  
  # batch control
  if(correct.batch) {
    batch <- as.factor(batch);
    # check batch-group interactions
    bgti <- table(groups,batch);
    bgti.ft <- fisher.test(bgti);
    if(verbose) {
      cat("controlling for batch effects. interaction:\n");
      print(bgti);
    }
    #if(any(bgti==0)) {
    #  cat("ERROR: cannot control for batch effect, as some batches are found only in one group:\n")
    #  print(bgti);
    #}
    if(bgti.ft$p.value<1e-3) {
      cat("WARNING: strong interaction between groups and batches! Correction may be ineffective:\n")
      print(bgti.ft);
    }
    
    # calculate batch posterior
    if(verbose) {
      cat("calculating batch posteriors\n");
    }
    batch.jpl <- tapply(1:nrow(models),groups,function(ii) {
      scde.posteriors(models=batch.models,counts=counts,prior=prior,batch=batch,composition=table(batch[ii]),n.cores=n.cores,n.randomizations=n.randomizations,return.individual.posteriors=F)
    })
    if(verbose) {
      cat("calculating batch differences\n");
    }
    batch.bdiffp <- calculate.ratio.posterior(batch.jpl[[1]],batch.jpl[[2]],prior,n.cores=n.cores)
    batch.bdiffp.rep <- quick.distribution.summary(batch.bdiffp)
  } else {
    if(verbose) {
      cat("comparing groups:\n");
      print(table(as.character(groups)));
    }
  }


  # fit joint posteriors for each group
  jpl <- tapply(1:nrow(models),groups,function(ii) {
    scde.posteriors(models=models[ii,,drop=F],counts=counts[,ii,drop=F],prior=prior,n.cores=n.cores,n.randomizations=n.randomizations)
  })
  if(verbose) {
    cat("calculating difference posterior\n");
  }
  # calcualte difference posterior
  bdiffp <- calculate.ratio.posterior(jpl[[1]],jpl[[2]],prior,n.cores=n.cores)
  
  if(verbose) {
    cat("summarizing differences\n");
  }
  bdiffp.rep <- quick.distribution.summary(bdiffp)
  
  if(correct.batch) {
    if(verbose) {
      cat("adjusting for batch effects\n");
    }
    # adjust for batch effects
    a.bdiffp <- calculate.ratio.posterior(bdiffp,batch.bdiffp,prior=data.frame(x=as.numeric(colnames(bdiffp)),y=rep(1/ncol(bdiffp),ncol(bdiffp))),skip.prior.adjustment=T)
    a.bdiffp.rep <- quick.distribution.summary(a.bdiffp)

    # return with batch correction info
    if(return.posteriors) {
      return(list(batch.adjusted=a.bdiffp.rep,results=bdiffp.rep,batch.effect=batch.bdiffp.rep,difference.posterior=bdiffp,batch.adjusted.difference.posterior=a.bdiffp,joint.posteriors=jpl))
    } else {
      return(list(batch.adjusted=a.bdiffp.rep,results=bdiffp.rep,batch.effect=batch.bdiffp.rep))
    }
  } else {
    # no batch correction return
    if(return.posteriors) {
      return(list(results=bdiffp.rep,difference.posterior=bdiffp,joint.posteriors=jpl))
    } else {
      return(bdiffp.rep)
    }
  }
}

##' View differential expression results in a browser
##'
##' Launches a browser app that shows the differential expression results, allowing to sort, filter, etc.
##' The arguments generally correspond to the \code{scde.expression.difference()} call, except that the results of that call are also passed here. Requires \code{Rook} and \code{rjson} packages to be installed.
##' @param results result object returned by \code{scde.expression.difference()}. Note to browse group posterior levels, use \code{return.posteriors=T} in the \code{scde.expression.difference()} call.
##' @param models model matrix
##' @param counts count matrix
##' @param prior prior
##' @param groups group information
##' @param batch batch information
##' @param geneLookupURL The URL that will be used to construct links to view more information on gene names. By default (if can't guess the organism) the links will forward to ENSEMBL site search, using \code{geneLookupURL="http://useast.ensembl.org/Multi/Search/Results?q={0}"}. The "{0}" in the end will be substituted with the gene name. For instance, to link to GeneCards, use \code{"http://www.genecards.org/cgi-bin/carddisp.pl?gene={0}"}. 
##' @param server optional previously returned instance of the server, if want to reuse it.
##' @param name app name (needs to be altered only if adding more than one app to the server using \code{server} parameter)
##' @return server instance, on which $stop() function can be called to kill the process.
##' @export
scde.browse.diffexp <- function(results,models,counts,prior,groups=NULL,batch=NULL,geneLookupURL=NULL,server=NULL, name="scde") {
  #require(Rook);
  #require(rjson);
  if(is.null(server)) {
    if(exists("___scde.server",envir=globalenv())) {
      server <- get("___scde.server",envir=globalenv())
    } else {
      server <- Rhttpd$new()
      assign("___scde.server",server,envir=globalenv())
      server$start(listen='127.0.0.1')
    }
  }
  sa <- ViewDiff$new(results,models,counts,prior,groups=groups,batch=batch,geneLookupURL=geneLookupURL)
  server$add(app=sa,name=name);
  browseURL(paste(server$full_url(name),"index.html",sep="/"))
  return(server);
}


# calculate indivdual and joint posterior information
# models - all or a subset of models belonging to a particular group
#
##' Calculate joint expression magnitude posteriors across a set of cells
##'
##' Calculates expression magnitude posteriors for the individual cells, and then uses boostrap resampling to calculate a joint expression posterior for all the specified cells. Alternatively during batch-effect correction procedure, the joint posterior can be calculated for a random composition of cells of different groups (see \code{batch} and \code{composition} parameters).
##' @param models models models determiend by \code{\link{scde.error.models}}
##' @param counts read count matrix
##' @param prior gene expression prior as determiend by \code{\link{scde.expression.prior}}
##' @param n.randomizations number of bootstrap iterations to perform
##' @param batch a factor describing which batch group each cell (i.e. each row of \code{models} matrix) belongs to
##' @param composition a vector describing the batch compoisition of a group to be sampled
##' @param return.individual.posteriors whether exprssion posteriors of each cell should be returned
##' @param return.individual.posterior.modes whether modes of expression posteriors of each cell should be returned
##' @param n.cores number of cores to utilize 
##' @return \subsection{default}{ a posterior probability matrix, with rows corresponding to genes, and columns to expression levels (as defined by \code{prior$x})
##' }
##' \subsection{return.individual.posterior.modes}{ a list is returned, with the \code{$jp} slot giving the joint posterior matrix, as described above. The \code{$modes} slot gives a matrix of individual expression posterior mode values on log scale (rows - genes, columns -cells)}
##' \subsection{return.individual.posteriors}{ a list is returned, with the \code{$post} slot giving a list of individual posterior matrices, in a form analogous to the joint posterior matrix }
##' 
##' @export
scde.posteriors <- function(models,counts,prior,n.randomizations=100,batch=NULL,composition=NULL,return.individual.posteriors=F,return.individual.posterior.modes=F,n.cores=20) {
  if(!all(rownames(models) %in% colnames(counts))) { stop("ERROR: provided count data does not cover all of the cells specified in the model matrix") }
  if(!is.null(batch)) { # calculating batch-sampled posteriors instead of evenly sampled ones
    if(is.null(composition)) { stop("ERROR: group composition must be provided if the batch argument is passed") }
    batchil <- tapply(c(1:nrow(models))-1,batch,I);
  }
  # order counts according to the cells
  ci <- match(rownames(models),colnames(counts))
  counts <- as.matrix(counts[,ci,drop=F]);
  marginals <- 10^prior$x - 1; marginals[marginals<0] <- 0; marginals <- log(marginals)

  min.slope <- 1e-10;
  if(any(models$corr.a<min.slope)) {
    cat("WARNING: the following cells have negatively-correlated or 0-slope fits: ",paste(rownames(models)[models$corr.a<min.slope],collapse=" "),". Setting slopes to 1e-10.\n");
    models$corr.a[models$corr.a<min.slope] <- min.slope;
  }
  
  models <- as.matrix(models);

  postflag <- 0;
  if(return.individual.posteriors) {
    postflag <- 2;
    if(return.individual.posterior.modes) {
      postflag <- 3;
    }
  } else if(return.individual.posterior.modes) {
    postflag <- 1;
  }
  chunk <- function(x, n) split(x, sort(rank(x) %% n.cores))
  if(n.cores>1 && nrow(counts)>n.cores) { # split by genes
    xl <- mclapply(chunk(1:nrow(counts),n.cores),function(ii) {
      ucl <- lapply(1:ncol(counts),function(i) as.vector(unique(counts[ii,i,drop=F])))
      uci <- do.call(cbind,lapply(1:ncol(counts),function(i) match(counts[ii,i,drop=F],ucl[[i]])-1))
      #x <- logBootPosterior(models,ucl,uci,marginals,n.randomizations,1,postflag);
      if(!is.null(batch)) {
        x <- .Call("logBootBatchPosterior", models, ucl, uci,marginals,batchil,composition,n.randomizations,ii[1],postflag, PACKAGE = "scde")
      } else {
        x <- .Call("logBootPosterior", models, ucl, uci,marginals,n.randomizations,ii[1],postflag, PACKAGE = "scde")
      }
    },mc.cores=n.cores)
    if(postflag==0) {
      x <- do.call(rbind,xl);
    } else if(postflag==1) {
      x <- list(jp=do.call(rbind,lapply(xl,function(d) d$jp)),modes=do.call(rbind,lapply(xl,function(d) d$modes)))
    } else if(postflag==2) {
      x <- list(jp=do.call(rbind,lapply(xl,function(d) d$jp)),post=lapply(1:length(xl[[1]]$post),function(pi) { do.call(rbind,lapply(xl,function(d) d$post[[pi]])) }))
    } else if(postflag==3) {
      x <- list(jp=do.call(rbind,lapply(xl,function(d) d$jp)),modes=do.call(rbind,lapply(xl,function(d) d$modes)),post=lapply(1:length(xl[[1]]$post),function(pi) { do.call(rbind,lapply(xl,function(d) d$post[[pi]])) }))
    }
    rm(xl); gc();
  } else {
    # unique count lists with matching indecies
    ucl <- lapply(1:ncol(counts),function(i) as.vector(unique(counts[,i,drop=F])))
    uci <- do.call(cbind,lapply(1:ncol(counts),function(i) match(counts[,i,drop=F],ucl[[i]])-1))
    #x <- logBootPosterior(models,ucl,uci,marginals,n.randomizations,1,postflag);
    if(!is.null(batch)) {
      x <- .Call("logBootBatchPosterior", models, ucl, uci,marginals,batchil,composition,n.randomizations,1,postflag, PACKAGE = "scde")
      } else { 
        x <- .Call("logBootPosterior", models, ucl, uci,marginals,n.randomizations,1,postflag, PACKAGE = "scde")
      }
  }
  if(postflag==0) {
    rownames(x) <- rownames(counts); colnames(x) <- as.character(exp(marginals));
  } else if(postflag==1) {
    rownames(x$jp) <- rownames(counts); colnames(x$jp) <- as.character(exp(marginals));
    rownames(x$modes) <- rownames(counts); colnames(x$modes) <- rownames(models);
  } else if(postflag==2) {
    rownames(x$jp) <- rownames(counts); colnames(x$jp) <- as.character(exp(marginals));
    names(x$post) <- rownames(models);
    x$post <- lapply(x$post,function(d) { rownames(d) <- rownames(counts); colnames(d) <- as.character(exp(marginals)); d; })
  } else if(postflag==3) {
    rownames(x$jp) <- rownames(counts); colnames(x$jp) <- as.character(exp(marginals));
    rownames(x$modes) <- rownames(counts); colnames(x$modes) <- rownames(models);
    names(x$post) <- rownames(models);
    x$post <- lapply(x$post,function(d) { rownames(d) <- rownames(counts); colnames(d) <- as.character(exp(marginals)); d; })
  }
  x
}


# get estimates of expression magnitude for a given set of models
# models - entire model matrix, or a subset of cells (i.e. select rows) of the model matrix for which the estimates should be obtained
# counts - count data that covers the desired set of genes (rows) and all specified cells (columns)
# return - a matrix of log(fpm) estimates with genes as rows and cells  as columns (in the model matrix order).
##' Return scaled expression magnitude estimates
##'
##' Return point estimates of expression magnitudes of each gene across a set of cells, based on the regression slopes determined during the model fitting procedure.
##' @param models models determiend by \code{\link{scde.error.models}}
##' @param counts count matrix
##' @return a matrix of expression magnitudes on a log scale (rows - genes, columns - cells)
##' @export
scde.expression.magnitude <- function(models,counts) {
  if(!all(rownames(models) %in% colnames(counts))) { stop("ERROR: provided count data does not cover all of the cells specified in the model matrix") }
  t((t(log(counts[,rownames(models),drop=F]))-models$corr.b)/models$corr.a)
}

# calculate drop-out probability given either count data or magnitudes (log(fpm))
# magnitudes can either be a per-cell matrix or a single vector of values which will be evaluated for each cell
# returns a probability of a drop out event for every gene (rows) for every cell (columns) 
##' Caclulate drop-out probabilities given a set of counts or expressio nmagnitudes
##'
##' Returns estimated drop-out probability for each cell (row of \code{models} matrix), given either an expression magnitude
##' @param models models determiend by \code{\link{scde.error.models}}
##' @param magnitudes a vector (\code{length(counts)==nrows(models)}) or a matrix (columns correspond to cells) of expression magnitudes, given on a log scale
##' @param counts a vector (\code{length(counts)==nrows(models)}) or a matrix (columns correspond to cells) of read counts from which the expression magnitude should be estimated
##' @return a vector or a matrix of drop-out probabilities
##' @export
scde.failure.probability <- function(models,magnitudes=NULL,counts=NULL) {
  if(is.null(magnitudes)) {
    if(!is.null(counts)) {
      magnitudes <- scde.expression.magnitude(models,counts)
    } else {
      stop("ERROR: either magnitudes or counts should be provided")
    }
  }
  if(is.matrix(magnitudes)) { # a different vector for every cell
    if(!all(rownames(models) %in% colnames(magnitudes))) { stop("ERROR: provided magnitude data does not cover all of the cells specified in the model matrix") }
    x <- t(1/(exp(t(magnitudes)*models$conc.a + models$conc.b)+1))
  } else { # a common vector of magnitudes for all cells
    x <- t(1/(exp((models$conc.a %*% t(magnitudes)) + models$conc.b)+1))
  }
  colnames(x) <- rownames(models);
  x
}


##' Test differential expression and plot posteriors for a particular gene
##'
##' The function performs differential expression test and optionally plots posteriors for a specified gene. 
##' @param gene name of the gene to be tested
##' @param models models
##' @param counts read count matrix (must contain the row corresponding to the specified gene)
##' @param prior expression magntiude prior
##' @param groups a two-level factor specifying between which cells (rows of the models matrix) the comparison should be made
##' @param batch optional multi-level factor assigning the cells (rows of the model matrix) to different batches that should be controlled for (e.g. two or more biological replicates). The expression difference estimate will then take into account the likely difference between the two groups that is explained solely by their difference in batch composition. Not all batch configuration may be corrected this way. 
##' @param batch.models optional set of models for batch comparison (typically the same as models, but can be more extensive, or recalculated within each batch)
##' @param n.randomizations number of bootstrap/sampling iterations that should be performed
##' @param show.plots whether the plots should be shown
##' @param return.details whether the posterior should be returned
##' @param verbose set to T for some status output
##' @param ratio.range optionally specifies the range of the log2 expression ratio plot
##' @param show.individual.posteriors whether the individual cell expression posteriors should be plotted
##' @param n.cores number of cores to use (default=1)
##' @return by default returns MLE of log2 expression difference, 95% CI (upper, lower bound), and a Z-score testing for expression difference. If return.details=T, a list is returned containing the above structure, as well as the expression fold difference posterior itself.
##' @export
scde.test.gene.expression.difference <- function(gene,models,counts,prior,groups=NULL,batch=NULL,batch.models=models,n.randomizations=1e3,show.plots=T,return.details=F,verbose=F,ratio.range=NULL,show.individual.posteriors=T,n.cores=1) {
  if(!gene %in% rownames(counts)) {
    stop("ERROR: specified gene (",gene,") is not found in the count data");
  }

  ci <- match(rownames(models),colnames(counts))
  counts <- as.matrix(counts[gene,ci,drop=F]);
  
  
  if(is.null(groups)) { # recover groups from models
    groups <- as.factor(attr(models,"groups"));
    if(is.null(groups)) stop("ERROR: groups factor is not provided, and models structure is lacking groups attribute");
    names(groups) <- rownames(models)
  }
  if(length(levels(groups))!=2) {
    stop(paste("ERROR: wrong number of levels in the grouping factor (",paste(levels(groups),collapse=" "),"), but must be two.",sep=""))
  }

  if(verbose) {
    cat("comparing gene ",gene," between groups:\n");
    print(table(as.character(groups)));
  }

  # calculate joint posteriors
  jpl <- tapply(1:nrow(models),groups,function(ii) {
    scde.posteriors(models=models[ii,,drop=F],counts=counts[,ii,drop=F],prior=prior,n.cores=n.cores,n.randomizations=n.randomizations,return.individual.posteriors=T)
  })

  bdiffp <- calculate.ratio.posterior(jpl[[1]]$jp,jpl[[2]]$jp,prior,n.cores=n.cores)

  bdiffp.rep <- quick.distribution.summary(bdiffp)

  nam1 <- levels(groups)[1]; nam2 <- levels(groups)[2];

  # batch control
  correct.batch <- !is.null(batch) && length(levels(batch))>1
  if(correct.batch) {
    batch <- as.factor(batch);
    # check batch-group interactions
    bgti <- table(groups,batch);
    bgti.ft <- fisher.test(bgti);
    if(verbose) {
      cat("controlling for batch effects. interaction:\n");
    }
    if(any(bgti==0)) {
      cat("ERROR: cannot control for batch effect, as some batches are found only in one group:\n")
      print(bgti);
    }
    if(bgti.ft$p.value<1e-3) {
      cat("WARNING: strong interaction between groups and batches! Correction may be ineffective:\n")
      print(bgti);
      print(bgti.ft);
    }
    # calculate batch posterior
    batch.jpl <- tapply(1:nrow(models),groups,function(ii) {
      scde.posteriors(models=batch.models,counts=counts,prior=prior,batch=batch,composition=table(batch[ii]),n.cores=n.cores,n.randomizations=n.randomizations,return.individual.posteriors=F)
    })
    batch.bdiffp <- calculate.ratio.posterior(batch.jpl[[1]],batch.jpl[[2]],prior,n.cores=n.cores)
    a.bdiffp <- calculate.ratio.posterior(bdiffp,batch.bdiffp,prior=data.frame(x=as.numeric(colnames(bdiffp)),y=rep(1/ncol(bdiffp),ncol(bdiffp))),skip.prior.adjustment=T)
    a.bdiffp.rep <- quick.distribution.summary(a.bdiffp)
  }
  
  
  if(show.plots) {
    # show each posterior
    layout(matrix(c(1:3),3,1,byrow=T),heights=c(2,1,2),widths=c(1),F)
    par(mar = c(2.5,3.5,2.5,3.5), mgp = c(1.5,0.65,0), cex = 0.9);
    #par(mar = c(2.5,3.5,0.5,3.5), mgp = c(1.5,0.65,0), cex = 0.9);

    pp <- exp(do.call(rbind,lapply(jpl[[1]]$post,as.numeric)))
    cols <- rainbow(nrow(pp),s=0.8)
    plot(c(),c(),xlim=range(prior$x),ylim=range(c(0,pp)),xlab="expression level",ylab="individual posterior",main=nam1)
    if(show.individual.posteriors) {
      lapply(1:nrow(pp),function(i) lines(prior$x,pp[i,],col=rgb(1,0.5,0,alpha=0.25)))
    }
    #legend(x=ifelse(which.max(na.omit(pjpc))>length(pjpc)/2,"topleft","topright"),bty="n",col=cols,legend=rownames(pp),lty=rep(1,nrow(pp)))
    if(correct.batch) {
      par(new=T)
      plot(prior$x,batch.jpl[[1]][1,],axes=F,ylab="",xlab="",type='l',col=8,lty=1,lwd=2)
    }
    pjpc <- jpl[[1]]$jp
    par(new=T)
    jpr <- range(c(0,na.omit(pjpc)))
    plot(prior$x,pjpc,axes=F,ylab="",xlab="",ylim=jpr,type='l',col=1,lty=1,lwd=2)
    axis(4,pretty(jpr,5),col=1)
    mtext("joint posterior",side=4,outer=F,line=2)
    

    # ratio plot
    if(is.null(ratio.range)) { ratio.range <- range(as.numeric(colnames(bdiffp))/log10(2)); }

    par(mar = c(2.5,3.5,0.5,3.5), mgp = c(1.5,0.65,0), cex = 0.9);
    rv <- as.numeric(colnames(bdiffp))/log10(2)
    rp <- as.numeric(bdiffp[1,]);
    plot(rv,rp,xlab="log2 expression ratio",ylab="ratio posterior",type='l',lwd=ifelse(correct.batch,1,2),main="",axes=F,xlim=ratio.range,ylim=c(0,max(bdiffp)))
    axis(1,pretty(ratio.range,5),col=1)
    abline(v=0,lty=2,col=8)
    if(correct.batch) { # with batch correction
      # show batch difference
      par(new=T)
      plot(as.numeric(colnames(batch.bdiffp))/log10(2),as.numeric(batch.bdiffp[1,]),xlab="",ylab="",type='l',lwd=1,main="",axes=F,xlim=ratio.range,col=8,ylim=c(0,max(batch.bdiffp)))
      # fill out the a.bdiffp confidence interval
      par(new=T)
      rv <- as.numeric(colnames(a.bdiffp))/log10(2)
      rp <- as.numeric(a.bdiffp[1,]);
      plot(rv,rp,xlab="",ylab="",type='l',lwd=2,main="",axes=F,xlim=ratio.range,col=2,ylim=c(0,max(rp)))
      axis(2,pretty(c(0,max(a.bdiffp)),2),col=1)
      r.lb <- which.min(abs(rv-a.bdiffp.rep$lb))
      r.ub <- which.min(abs(rv-a.bdiffp.rep$ub))
      polygon(c(rv[r.lb],rv[r.lb:r.ub],rv[r.ub]),y=c(-10,rp[r.lb:r.ub],-10),col=rgb(1,0,0,alpha=0.2),border=NA)
      abline(v=a.bdiffp.rep$mle,col=2,lty=2)
      abline(v=c(rv[r.ub],rv[r.lb]),col=2,lty=3)
      
      legend(x=ifelse(a.bdiffp.rep$mle>0,"topleft","topright"),legend=c(paste("MLE: ",round(a.bdiffp.rep$mle,2),sep=""),paste("95% CI: ",round(a.bdiffp.rep$lb,2)," : ",round(a.bdiffp.rep$ub,2),sep=""),paste("Z=",round(a.bdiffp.rep$Z,2),sep=""),paste("cZ=",round(a.bdiffp.rep$cZ,2),sep="")),bty="n")

    } else {  # without batch correction
      # fill out the bdiffp confidence interval
      axis(2,pretty(c(0,max(bdiffp)),2),col=1)
      
      r.lb <- which.min(abs(rv-bdiffp.rep$lb))
      r.ub <- which.min(abs(rv-bdiffp.rep$ub))
      polygon(c(rv[r.lb],rv[r.lb:r.ub],rv[r.ub]),y=c(-10,rp[r.lb:r.ub],-10),col=rgb(1,0,0,alpha=0.2),border=NA)
      abline(v=bdiffp.rep$mle,col=2,lty=2)
      abline(v=c(rv[r.ub],rv[r.lb]),col=2,lty=3)
      
      legend(x=ifelse(bdiffp.rep$mle>0,"topleft","topright"),legend=c(paste("MLE: ",round(bdiffp.rep$mle,2),sep=""),paste("95% CI: ",round(bdiffp.rep$lb,2)," : ",round(bdiffp.rep$ub,2),sep=""),paste("Z=",round(bdiffp.rep$Z,2),sep=""),paste("aZ=",round(bdiffp.rep$cZ,2),sep="")),bty="n")
    }
      
    # distal plot
    par(mar = c(2.5,3.5,2.5,3.5), mgp = c(1.5,0.65,0), cex = 0.9);
    #par(mar = c(2.5,3.5,0.5,3.5), mgp = c(1.5,0.65,0), cex = 0.9);
    dp <- exp(do.call(rbind,lapply(jpl[[2]]$post,as.numeric)))
    cols <- rainbow(nrow(dp),s=0.8)
    plot(c(),c(),xlim=range(prior$x),ylim=range(c(0,dp)),xlab="expression level",ylab="individual posterior",main=nam2)
    if(show.individual.posteriors) {
      lapply(1:nrow(dp),function(i) lines(prior$x,dp[i,],col=rgb(0,0.5,1,alpha=0.25)))
    }
    if(correct.batch) {
      par(new=T)
      plot(prior$x,batch.jpl[[2]][1,],axes=F,ylab="",xlab="",type='l',col=8,lty=1,lwd=2)
    }
    djpc <- jpl[[2]]$jp
    #legend(x=ifelse(which.max(na.omit(djpc))>length(djpc)/2,"topleft","topright"),bty="n",col=cols,legend=rownames(dp),lty=rep(1,nrow(dp)))
    par(new=T)
    jpr <- range(c(0,na.omit(djpc)))
    plot(prior$x,djpc,axes=F,ylab="",xlab="",ylim=jpr,type='l',col=1,lty=1,lwd=2)
    axis(4,pretty(jpr,5),col=1)
    mtext("joint posterior",side=4,outer=F,line=2)
  }

  if(return.details) {
    if(correct.batch) { # with batch correction
      return(list(results=a.bdiffp.rep,difference.posterior=a.bdiffp,results.nobatchcorrection=bdiffp.rep))
    } else {
      return(list(results=bdiffp.rep,difference.posterior=bdiffp,posteriors=jpl))
    }
  } else {
    if(correct.batch) { # with batch correction
      return(a.bdiffp.rep)
    } else {
      return(bdiffp.rep)
    }
  }
}



# fit models to external (bulk) reference
##' fit scde models relative to provided set of expression magnitudes
##'
##' If group-average expression magnitudes are available (e.g. from bulk measurement), this method can be used
##' to fit individual cell error models relative to that reference
##' @param counts count matrix
##' @param reference a vector of expression magnitudes (read counts) corresponding to the rows of the count matrix
##' @param min.fpm minimum reference fpm of genes that will be used to fit the models (defaults to 1). Note: fpm is calculated from the reference count vector as reference/sum(reference)*1e6;
##' @param n.cores number of cores to use
##' @param zero.count.threshold read count to use as an initial guess for the zero threshold
##' @param nrep number independent of mixture fit iterations to try (default=1)
##' @param save.plots whether to write out a pdf file showing the model fits
##' @param plot.filename model fit pdf fielname 
##' @param verbose verbose level
##' 
##' @return matrix of scde models
##'
##' @export
scde.fit.models.to.reference <- function(counts,reference,n.cores=10,zero.count.threshold=1,nrep=1,save.plots=F,plot.filename="reference.model.fits.pdf",verbose=0,min.fpm=1) {
  old.fit <- T; return.compressed.models <- T;
  verbose <- 1;
  ids <- colnames(counts);
  ml <- mclapply(1:length(ids),function(i) {
    df <- data.frame(count=counts[,ids[i]],fpm=reference/sum(reference)*1e6)
    df <- df[df$fpm>min.fpm,]
    m1 <- fit.nb2.mixture.model(df,nrep=nrep,verbose=verbose,zero.count.threshold=zero.count.threshold);
    if(return.compressed.models) {
      v <- get.compressed.v1.model(m1);
      cl <- clusters(m1);
      rm(m1); gc();
      return(list(model=v,clusters=cl));
    } else {
      return(m1);
    }
  },mc.cores=n.cores,mc.preschedule=F)
  names(ml) <- ids;
  
  # check if there were errors in the multithreaded portion
  lapply(1:length(ml),function(i) {
    if(class(ml[[i]])=="try-error") {
      message("ERROR encountered in building a model for cell ",ids[i],":");
      message(ml[[i]]);
      tryCatch(stop(paste("ERROR encountered in building a model for cell ",ids[i])),error=function(e) stop(e))
    }
  })

  if(save.plots) {
    # model fits
    #CairoPNG(file=paste(group,"model.fits.png",sep="."),width=1024,height=300*length(ids));
    pdf(file=plot.filename,width=ifelse(old.fit,13,15),height=4)
    #l <- layout(matrix(seq(1,4*length(ids)),nrow=length(ids),byrow=T),rep(c(1,1,1,0.5),length(ids)),rep(1,4*length(ids)),FALSE);
    l <- layout(matrix(seq(1,4),nrow=1,byrow=T),rep(c(1,1,1,ifelse(old.fit,0.5,1)),1),rep(1,4),FALSE);
    par(mar = c(3.5,3.5,3.5,0.5), mgp = c(2.0,0.65,0), cex = 0.9);
    invisible(lapply(1:length(ids),function(i) {
      df <- data.frame(count=counts[,ids[i]],fpm=reference/sum(reference)*1e6)
      df <- df[df$fpm>min.fpm,]
      if(old.fit) {
        plot.nb2.mixture.fit(ml[[i]],df,en=ids[i],do.par=F,compressed.models=return.compressed.models);
      }
    }))
    dev.off();
  }
  
  if(return.compressed.models) {
    # make a joint model matrix
    jmm <- data.frame(do.call(rbind,lapply(ml,function(m) m$model)));
    rownames(jmm) <- names(ml);
    jmm
    return(jmm);
  } else {
    return(ml);
  }
}









one.sided.test.id <- function(id,nam1,nam2,ifm,dm,prior,difference.prior=0.5,bootstrap=T,n.samples=1e3,show.plots=T,return.posterior=F,return.both=F) {
  gr <- 10^prior$x - 1; gr[gr<0] <- 0;
  lpp <- get.rep.set.general.model.logposteriors(ifm[[nam1]],dm[rep(id,length(gr)),names(ifm[[nam1]])],data.frame(fpm=gr),grid.weight=prior$grid.weight)
  ldp <- get.rep.set.general.model.logposteriors(ifm[[nam2]],dm[rep(id,length(gr)),names(ifm[[nam2]])],data.frame(fpm=gr),grid.weight=prior$grid.weight)

  if(bootstrap) {
    pjp <- do.call(cbind,lapply(1:n.samples,function(i) {
      pjp <- rowSums(lpp[,sample(1:ncol(lpp),replace=T)]);
      pjp <- exp(pjp-max(pjp)); pjp <- pjp/sum(pjp)
      pjp
    }));
    pjp <- rowSums(pjp); pjp <- log(pjp/sum(pjp));
    
    djp <- do.call(cbind,lapply(1:n.samples,function(i) {
      djp <- rowSums(ldp[,sample(1:ncol(ldp),replace=T)]);
      djp <- exp(djp-max(djp)); djp <- djp/sum(djp);
      djp
    }));
    djp <- rowSums(djp); djp <- log(djp/sum(djp));
  } else {
    pjp <- rowSums(lpp);
    djp <- rowSums(ldp);
  }

  dpy <- exp(prior$lp+djp)
  mpgr <- sum(exp(prior$lp+pjp+log(c(0,cumsum(dpy)[-length(dpy)])))) # m1
  mpls <- sum(exp(prior$lp+pjp+log(sum(dpy)-cumsum(dpy)))) # m0
  mpls/mpgr
  
  pjpc <- exp(prior$lp+pjp);
  pjpc <- pjpc/sum(pjpc);
  djpc <- exp(prior$lp+djp)
  djpc <- djpc/sum(djpc);
  
  
  if(show.plots || return.posterior || return.both) { 
    # calculate log-fold-change posterior
    n <- length(pjpc)
    rp <- c(unlist(lapply(n:2,function(i) sum(pjpc[1:(n-i+1)]*djpc[i:n]))),unlist(lapply(1:n,function(i) sum(pjpc[i:n]*djpc[1:(n-i+1)]))))
    rv <- seq(prior$x[1]-prior$x[length(prior$x)],prior$x[length(prior$x)]-prior$x[1],length=length(prior$x)*2-1)
    fcp <- data.frame(v=rv,p=rp);
  }
  
  if(show.plots) {
    # show each posterior
    layout(matrix(c(1:3),3,1,byrow=T),heights=c(2,1,2),widths=c(1),F)
    par(mar = c(2.5,3.5,2.5,3.5), mgp = c(1.5,0.65,0), cex = 0.9);
    jpr <- range(c(0,pjpc),na.rm=T);
    pp <- exp(lpp);
    cols <- rainbow(dim(pp)[2],s=0.8)
    plot(c(),c(),xlim=range(prior$x),ylim=range(c(0,pp)),xlab="expression level",ylab="individual posterior",main=nam1)
    lapply(1:(dim(pp)[2]),function(i) lines(prior$x,pp[,i],col=cols[i]))
    legend(x=ifelse(which.max(na.omit(pjpc))>length(pjpc)/2,"topleft","topright"),bty="n",col=cols,legend=colnames(pp),lty=rep(1,dim(pp)[2]))
    par(new=T)
    plot(prior$x,pjpc,axes=F,ylab="",xlab="",ylim=jpr,type='l',col=1,lty=1,lwd=2)
    axis(4,pretty(jpr,5),col=1)
    mtext("joint posterior",side=4,outer=F,line=2)

    # ratio plot
    par(mar = c(2.5,3.5,0.5,3.5), mgp = c(1.5,0.65,0), cex = 0.9);
    plot(fcp$v,fcp$p,xlab="log10 expression ratio",ylab="ratio posterior",type='l',lwd=2,main="")
    r.mle <- fcp$v[which.max(fcp$p)]
    r.lb <- max(which(cumsum(fcp$p)<0.025))
    r.ub <- min(which(cumsum(fcp$p)>(1-0.025)))
    polygon(c(fcp$v[r.lb],fcp$v[r.lb:r.ub],fcp$v[r.ub]),y=c(-10,fcp$p[r.lb:r.ub],-10),col="grey90")
    abline(v=r.mle,col=2,lty=2)
    abline(v=c(fcp$v[r.ub],fcp$v[r.lb]),col=2,lty=3)
    box()
    legend(x=ifelse(r.mle>0,"topleft","topright"),legend=c(paste("MLE=",round(10^(r.mle),1)," (",round(r.mle,2)," in log10)",sep=""),paste("95% CI: ",round(10^(fcp$v[r.lb]),1)," - ",round(10^(fcp$v[r.ub]),1),sep=""),paste(" log10: ",round(fcp$v[r.lb],2)," - ",round(fcp$v[r.ub],2),sep="")),bty="n")

    # distal plot
    dp <- exp(ldp);
    par(mar = c(2.5,3.5,2.5,3.5), mgp = c(1.5,0.65,0), cex = 0.9);
    jpr <- range(c(0,djpc),na.rm=T);
    cols <- rainbow(dim(dp)[2],s=0.8)
    plot(c(),c(),xlim=range(prior$x),ylim=range(c(0,dp)),xlab="expression level",ylab="individual posterior",main=nam2)
    lapply(1:(dim(dp)[2]),function(i) lines(prior$x,dp[,i],col=cols[i]))
    legend(x=ifelse(which.max(na.omit(djpc))>length(djpc)/2,"topleft","topright"),bty="n",col=cols,legend=colnames(dp),lty=rep(1,dim(dp)[2]))
    
    par(new=T)
    plot(prior$x,djpc,axes=F,ylab="",xlab="",ylim=jpr,type='l',col=1,lty=1,lwd=2)
    axis(4,pretty(jpr,5),col=1)
    mtext("joint posterior",side=4,outer=F,line=2)
  }

  lbf <- mpls/mpgr;
  lbf <- (difference.prior*lbf)/(difference.prior*lbf+1-difference.prior)
  #return(c(equal=qnorm(ebf,lower.tail=T),less=qnorm(lbf,lower.tail=T)));
  if(return.both) {
    return(list(z=qnorm(lbf,lower.tail=T),post=fcp))
  } else if(return.posterior) {
    return(fcp);
  } else {
    return(qnorm(lbf,lower.tail=T));
  }
}

# counts - data frame with fragment counts (rows - fragments; columns -experiments)
# groups - a two-level factor describing grouping of columns. Use NA for observations that should be skipped
# min.count.threshold - the number of reads used to make an initial guess for the failed component
# threshold.segmentation - use min.count.threshold to perform very quick identification of the drop-outs
# threshold.prior - prior that should be associated with threshold segmentation
calculate.crossfit.models <- function(counts,groups,min.count.threshold=4,nrep=1,verbose=0,min.prior=1e-5,n.cores=12,save.plots=T,zero.lambda=0.1,old.cfm=NULL,threshold.segmentation=F,threshold.prior=1-1e-6,max.pairs=1000,min.pairs.per.cell=10) {
  names(groups) <- colnames(counts);
  # enumerate cross-fit pairs within each group
  cl <- do.call(cbind,tapply(colnames(counts),groups,function(ids) {
    cl <- combn(ids,2);
    min.pairs.per.cell <- min(length(ids)*(length(ids)-1)/2,min.pairs.per.cell)
    if(verbose) {
      cat("number of pairs: ",ncol(cl),"\n");
    }
    if(ncol(cl)>max.pairs) {
      if(verbose) {
        cat("reducing to a random sample of ",max.pairs," pairs\n")
      }
      
      # make sure there's at least min.pairs.per.cell pairs for each cell
      cl <- cl[,unique(c(sample(1:ncol(cl),max.pairs),
                         unlist(lapply(ids,function(id) sample(which(colSums(cl==id)>0),min.pairs.per.cell)))))] 
    }
    cl
  }))
  
  orl <- c();
  if(!is.null(old.cfm)) {
    # check which pairs have already been fitted in compared in old.cfm
    pn1 <- unlist(apply(cl,2,function(ii) paste(ii,collapse=".vs.")));
    pn2 <- unlist(apply(cl,2,function(ii) paste(rev(ii),collapse=".vs."))); ### %%% use rev() to revert element order
    vi <- (pn1 %in% names(old.cfm)) | (pn2 %in% names(old.cfm))
    cl <- cl[,!vi,drop=F]
    orl <- old.cfm[names(old.cfm) %in% c(pn1,pn2)];
  }
  if(verbose) {
    cat("total number of pairs: ",ncol(cl),"\n");
  }
  
  if(dim(cl)[2]>0) {
    if(verbose)  message(paste("cross-fitting",ncol(cl),"pairs:"))
    rl <- mclapply(1:dim(cl)[2],function(cii) {
      ii <- cl[,cii];
      df <- data.frame(c1=counts[,ii[1]],c2=counts[,ii[2]])
      vi <- which(rowSums(df)>0,);
      if(!threshold.segmentation) {
        if(verbose) {
          message("fitting pair [",paste(ii,collapse=" "),"]");
        }
        mo1 <- FLXMRglmCf(c1~1,family="poisson",components=c(1),mu=log(zero.lambda))
        mo2 <- FLXMRnb2glmC(c1~1+I(log(c2+1)),components=c(2))
        mo3 <- FLXMRnb2glmC(c2~1+I(log(c1+1)),components=c(2))
        mo4 <- FLXMRglmCf(c2~1,family="poisson",components=c(3),mu=log(zero.lambda))
        m1 <- mc.stepFlexmix(c1~1,data=df[vi,],k=3,model=list(mo1,mo2,mo3,mo4),control=list(verbose=verbose,minprior=min.prior),concomitant=FLXPmultinom(~I((log(c1+1)+log(c2+1))/2)+1),cluster=cbind(df$c1[vi]<=min.count.threshold,df$c1[vi]>min.count.threshold & df$c2[vi]>min.count.threshold,df$c2[vi]<=min.count.threshold),nrep=nrep)
      
        # reduce return size
        m1@posterior <- lapply(m1@posterior,function(m) { rownames(m) <- NULL; return(m);})
        #rownames(m1@concomitant@x) <- NULL;
        m1@concomitant@x <- matrix();
        m1@model <- lapply(m1@model,function(mod) {
          mod@x <- matrix();
          mod@y <- matrix();
          #rownames(mod@x) <- NULL;
          #rownames(mod@y) <- NULL;
          return(mod);
        })
        
        #parent.env(environment(m1@components[[1]][[1]]@logLik)) <- globalenv();
        #parent.env(environment(m1@components[[1]][[2]]@logLik)) <- globalenv();
        #parent.env(environment(m1@components[[2]][[1]]@logLik)) <- globalenv();
        #parent.env(environment(m1@components[[2]][[2]]@logLik)) <- globalenv();


        
        names(vi) <- NULL;
        pm <- posterior(m1)[,c(1,3)]; rownames(pm) <- NULL;
        cl <- clusters(m1); names(cl) <- NULL;
        gc()
      } else {
        # use min.count.threshold to quickly segment the points
        cl <- rep(2,length(vi));
        cl[df[vi,1]<min.count.threshold] <- 1;
        cl[df[vi,2]<min.count.threshold] <- 3;
        names(cl) <- NULL;
        pm <- cbind(ifelse(cl==1,threshold.prior,1-threshold.prior),ifelse(cl==3,threshold.prior,1-threshold.prior));
        rownames(pm) <- NULL;
      }
      rli <- list(ii=ii,clusters=cl,posterior=pm,vi=vi);
      #message("return object size for pair [",paste(ii,collapse=" "),"] is ",round(object.size(rli)/(1024^2),3)," MB")
      return(rli);
    },mc.cores=round(n.cores/nrep),mc.preschedule=threshold.segmentation);
    names(rl) <- apply(cl,2,paste,collapse=".vs.")
    # clean up invalid entries
    rl <- rl[!unlist(lapply(rl,is.null))];
    rl <- rl[unlist(lapply(rl,is.list))]; 
    #names(rl) <- unlist(lapply(rl,function(d) paste(d$ii,collapse=".vs.")))
  } else {
    rl <- c();
  }
  
  if(!is.null(old.cfm)) rl <- c(rl,orl);

  if(save.plots) {
    #require(Cairo); require(RColorBrewer);
    tapply(colnames(counts),groups,function(ids) {
      cl <- combn(ids,2); group <- as.character(groups[ids[1]]);
      # log-scale hist
      t.pairs.panel.hist <- function(x, i=NULL, ...) { 
        usr <- par("usr"); on.exit(par(usr))
        par(usr = c(usr[1:2], 0, 1.5) )
        vi <- x>0;
        h <- hist(x, plot = FALSE)
        breaks <- h$breaks; nB <- length(breaks)
        y <- log10(h$counts); y <- y/max(y)
        rect(breaks[-nB], 0, breaks[-1], y, col="gray60", ...)
      }
      t.pairs.smoothScatter.spearman <- function(x,y,i=NULL, j=NULL, cex=0.8, ...) {
        vi <- x>0 | y>0; 
        smoothScatter(x[vi],y[vi], add=T, useRaster=T, ...)
        legend(x="bottomright",legend=paste("sr=",round(cor(x[vi],y[vi],method="spearman"),2),sep=""),bty="n",cex=cex);
      }
      # component assignment scatter
      t.panel.component.scatter <- function(x,y,i,j, cex=0.8, ...) {
        if(!is.null(rl[[paste(ids[i],"vs",ids[j],sep=".")]])) {
          m1 <- rl[[paste(ids[i],"vs",ids[j],sep=".")]];
          # forward plot
          vi <- which(x>0 | y>0);
          ci <- vi[m1$clusters==1];
          if(length(ci)>3) {
            points(x[ci],y[ci],pch=".",col=densCols(x[ci],y[ci],colramp=colorRampPalette(brewer.pal(9, "Reds")[-(1:3)])),cex=2)
          }
          
          ci <- vi[m1$clusters==3];
          if(length(ci)>3) {
            points(x[ci],y[ci],pch=".",col=densCols(x[ci],y[ci],colramp=colorRampPalette(brewer.pal(9, "Greens")[-(1:3)])),cex=2)
          }
          ci <- vi[m1$clusters==2];
          if(length(ci)>3) {
            points(x[ci],y[ci],pch=".",col=densCols(x[ci],y[ci],colramp=colorRampPalette(brewer.pal(9, "Blues")[-(1:3)])),cex=2)
          }
          legend(x="topleft",pch=c(19),col="blue",legend=paste("sr=",round(cor(x[ci],y[ci],method="spearman"),2),sep=""),bty="n",cex=cex);
          legend(x="bottomright",pch=c(rep(19,3)),col=c("red","blue","green"),legend=paste(round(unlist(tapply(m1$clusters,factor(m1$clusters,levels=c(1,2,3)),length))*100/length(vi),1),"%",sep=""),bty="n",cex=cex)
          
        } else if(!is.null(rl[[paste(ids[i],"vs",ids[j],sep=".")]])) {
          m1 <- rl[[paste(ids[j],"vs",ids[i],sep=".")]];
          # reverse plot
          vi <- which(x>0 | y>0);
          ci <- vi[m1$clusters==3];
          if(length(ci)>3) {
            points(x[ci],y[ci],pch=".",col=densCols(x[ci],y[ci],colramp=colorRampPalette(brewer.pal(9, "Reds")[-(1:3)])),cex=2)
          }
          
          ci <- vi[m1$clusters==1];
          if(length(ci)>3) {
            points(x[ci],y[ci],pch=".",col=densCols(x[ci],y[ci],colramp=colorRampPalette(brewer.pal(9, "Greens")[-(1:3)])),cex=2)
          }
          ci <- vi[m1$clusters==2];
          if(length(ci)>3) {
            points(x[ci],y[ci],pch=".",col=densCols(x[ci],y[ci],colramp=colorRampPalette(brewer.pal(9, "Blues")[-(1:3)])),cex=2)
          }
          legend(x="topleft",pch=c(19),col="blue",legend=paste("sr=",round(cor(x[ci],y[ci],method="spearman"),2),sep=""),bty="n",cex=cex);
          legend(x="bottomright",pch=c(rep(19,3)),col=c("red","blue","green"),legend=paste(round(unlist(tapply(m1$clusters,factor(m1$clusters,levels=c(3,2,1)),length))*100/length(vi),1),"%",sep=""),bty="n",cex=cex)
        } else {
          #message(paste("ERROR: unable to find model for i=",i,"j=",j))
          message(paste("INFO: coross-fit plots: skipping model for i=",i,"j=",j," (increase max.pairs parameter if needed"))
        }
      }
      #pdf(file=paste(group,"crossfits.pdf",sep="."),width=3*length(ids),height=3*length(ids));
      CairoPNG(filename=paste(group,"crossfits.png",sep="."),width=250*length(ids),height=250*length(ids));
      pairs.extended(log10(counts[,ids]+1),lower.panel=t.pairs.smoothScatter.spearman,upper.panel=t.panel.component.scatter,diag.panel=t.pairs.panel.hist,cex=1.5)
      dev.off();
    })
  }

  return(rl);
}

# estimates library sizes based on the correlated components
# min.size.entries - minimal number of entries (genes) used to determine scaling factors for individual experiments
# counts - data frame with fragment counts (rows - fragments; columns -experiments)
# groups - a two-level factor describing grouping of columns. Use NA for observations that should be skipped
# cfm - cross-fit models (return of calculate.crossfit.models())
# vil - optional binary matrix (corresponding to counts) with 0s marking likely drop-out observations
# return value - library size vector in millions of reads
estimate.library.sizes <- function(counts,cfm,groups,min.size.entries=min(nrow(counts),2e3),verbose=0,return.details=F, vil=NULL, ...) {
  #require(edgeR);
  names(groups) <- colnames(counts);
  # determine the set fragments that were not attributed to failure in any cross-comparison
  if(is.null(vil)) {
    x <- lapply(cfm,function(d) { ll <- list(!(1:nrow(counts)) %in% d$vi[which(d$clusters!=1)],!(1:nrow(counts)) %in% d$vi[which(d$clusters!=3)]); names(ll) <- d$ii; return(ll); })
    vil <- do.call(cbind,tapply(unlist(x,recursive=F),factor(unlist(lapply(x,names)),levels=colnames(counts)[!is.na(groups)]),function(l) { x <- rowSums(do.call(cbind,l),na.rm=F)==0; x[is.na(x)] <- F; return(x); }))
  }

  # order entries by the number of non-failed experiments,
  # select entries for library size estimation
  ni <- cbind(1:nrow(counts),rowSums(vil));
  ni <- ni[order(ni[,2],decreasing=T),]
  if(ni[min.size.entries,2]<ncol(vil)) {
    # if the min.size.entries -th gene has failures, take only min.size.entries genes
    gis <- ni[1:min.size.entries,1];
  } else {
    # otherwise take all genes that have not failed in any experiment
    gis <- ni[ni[,2]==ncol(vil),1];
  }
  
  if(verbose)  message(paste("adjusting library size based on",length(gis),"entries"))
  f <- calcNormFactors(as.matrix(counts[gis,!is.na(groups)]),...)
  f <- f/exp(mean(log(f)))
  ls <- colSums(counts[gis,!is.na(groups)])*f/1e6;
  if(return.details) { return(list(ls=ls,vil=vil)) } else { return(ls) }
}

# an alternative prior estimation procedure that weights down contributions by failure probability
# and uses pre-scaled fpkm guesses for magnitude estimates
estimate.signal.prior <- function(fpkm,fail,length.out=400,show.plot=F,pseudo.count=1,bw=0.1,max.quantile=0.999,max.value=NULL) {
  fpkm <- log10(exp(as.matrix(fpkm))+1);
  wts <- as.numeric(as.matrix(1-fail[,colnames(fpkm)]))
  wts <- wts/sum(wts);
  # fit density on a mirror image
  if(is.null(max.value)) {
    x <- as.numeric(fpkm);
    max.value <- as.numeric(quantile(x[x<Inf],p=max.quantile));
  }
  md <- density(c(-1*as.numeric(fpkm),as.numeric(fpkm)),bw=bw,weights=c(wts/2,wts/2),n=2*length.out+1,from=-1*max.value,to=max.value)
  
  gep <- data.frame(x=md$x[-c(1:length.out)],y=md$y[-c(1:length.out)])
  gep$y[is.na(gep$y)] <- 0;
  gep$y <- gep$y+pseudo.count/nrow(fpkm); # pseudo-count
  gep$y <- gep$y/sum(gep$y)
  if(show.plot) {
    par(mfrow=c(1,1),mar = c(3.5,3.5,3.5,0.5), mgp = c(2.0,0.65,0), cex = 0.9);
    plot(gep$x,gep$y,col=4,panel.first=abline(h=0,lty=2),type='l',xlab="log10( signal+1 )",ylab="probability density",main="signal prior")
  }
  gep$lp <- log(gep$y);

  # grid weighting (for normalization)
  gep$grid.weight <- diff(10^c(gep$x[1],gep$x+c(diff(gep$x)/2,0))-1);
  
  return(gep);
  plot(x)
}

# counts - data frame with gene counts (rows - genes; columns -experiments)
# groups - a two-level factor describing grouping of columns. Use NA for observations that should be skipped
# cfm - cross-fit models (return of calculate.crossfit.models())
# min.nonfailed - minimal number of non-failed observations required for a gene to be used in the final model fitting;
#  A minimum of either the specified value or number of experiments -1 will be used.
calculate.individual.models <- function(counts,groups,cfm,nrep=1,verbose=0,n.cores=12,min.nonfailed=2,min.size.entries=2e3,zero.count.threshold=10,save.plots=T, old.fit=T, return.compressed.models=F, ...) {
  names(groups) <- colnames(counts);
  # determine library size discarding non-zero entries
  ls <- estimate.library.sizes(counts,cfm,groups,min.size.entries,verbose=verbose,return.details=T)
  
  # fit three-component models to unique pairs within each group
  mll <- tapply(colnames(counts),groups,function(ids) {
    cl <- combn(ids,2); group <- as.character(groups[ids[1]]);
    
    # incorporate cross-fit paris from cfm
    pn1 <- unlist(apply(cl,2,function(ii) paste(ii,collapse=".vs.")));
    pn2 <- unlist(apply(cl,2,function(ii) paste(rev(ii),collapse=".vs."))); ### %%% use rev() to revert element order
    vi <- (pn1 %in% names(cfm)) | (pn2 %in% names(cfm)) # check both reverse and forward pairing
    #if(!all(vi)) stop("unable to find cross-fit models for the following pairs : ",paste(pn1[!vi]));
    if(!all(vi)) {
      if(verbose>0) {
        if(verbose>1) {
          cat(paste("WARNING: unable to find cross-fit models for the following pairs : ",paste(pn1[!vi],collapse=" ")),"\n");
        } else {
          cat("WARNING: unable to find cross-fit models for ",sum(!vi)," out of ",length(vi)," pairs. Using a subset.\n");
        }
      }
      # use a subset
      if(sum(vi)>3) {
        pn1 <- pn1[vi]; pn2 <- pn2[vi]; vi <- vi[vi];
      } else {
        stop("less than 3 valid cross-fit pairs are availabile! giving up.");
      }
    }
    
    #rl <- cfm[vi]
    vi.names<-names(cfm)[names(cfm) %in% c(pn1, pn2)] ### a similar selection was done like this in calculate.crossfit.models() function
    rl <- cfm[vi.names]  ### with this subselection we select only sample pairs within the current group (e.g. pairs of ES)

    # determine the set genes that were not attributed to failure in any cross-comparison
    x <- lapply(rl,function(d) { ll <- list(!(1:nrow(counts)) %in% d$vi[which(d$clusters!=1)],!(1:nrow(counts)) %in% d$vi[which(d$clusters!=3)]); names(ll) <- d$ii; return(ll); })
    vil <- do.call(cbind,tapply(unlist(x,recursive=F),factor(unlist(lapply(x,names)),levels=ids),function(l) { x <- rowSums(do.call(cbind,l),na.rm=F)==0; x[is.na(x)] <- F; return(x); }))
    
    #x <- lapply(rl,function(d) { ll <- list((d$failures==1),(d$failures==2)); names(ll) <- d$ii; return(ll); })
    #vil <- do.call(cbind,tapply(unlist(x,recursive=F),factor(unlist(lapply(x,names)),levels=ids),function(l) { x <- rowSums(do.call(cbind,l),na.rm=F)==0; x[is.na(x)] <- F; return(x); }))
    
    t.ls <- ls$ls[ids]
    adjust <- NULL; if(!is.null(ls$adjustments)) { ls$adjustments[[groups[ids[1]]]] }
    # fit two-NB2 mixture for each experiment
    if(verbose)  message(paste("fitting",group,"models:"))
    gc(); gc();
    
    # pair cell name matrix
    nm <- do.call(rbind,lapply(rl,function(x) x$ii))
    
    ml <- mclapply(1:length(ids),function(i) {
      if(verbose)  message(paste(i,":",ids[i]));
      # determine genes with sufficient number of non-failed observations in other experiments
      vi <- which(rowSums(vil[,-i,drop=F])>=min(length(ids)-1,min.nonfailed));
      fpm <- rowMeans(t(t(counts[vi,ids[-i],drop=F])/(t.ls[-i])))
      if(!is.null(adjust)) { fpm <- adjust(fpm)  }; # adjust for between-group systematic differences
      df <- data.frame(count=counts[vi,ids[i]],fpm=fpm)

      # reconstruct failure prior for the cell by averaging across
      # cross-cell comparisons where the cell did participate
      cp <- exp(rowMeans(log(cbind(
        do.call(cbind,lapply(rl[which(nm[,1]==ids[i])],function(d) {
          ivi <- rep(NA,nrow(counts)); ivi[d$vi] <- 1:length(d$vi);
        d$posterior[ivi[vi],1]
      })),
            do.call(cbind,lapply(rl[which(nm[,2]==ids[i])],function(d) {
        ivi <- rep(NA,nrow(counts)); ivi[d$vi] <- 1:length(d$vi);
        d$posterior[ivi[vi],2]
      })))),na.rm=T))
      cp <- cbind(cp,1-cp);

      nai <- which(is.na(cp[,1])); cp[nai,1] <- 1-(1e-10); cp[nai,2] <- (1e-10);
      if(old.fit) {
        m1 <- fit.nb2.mixture.model(df,prior=cp,nrep=nrep,verbose=verbose,zero.count.threshold=zero.count.threshold, ...);
      } else {
        #m1 <- fit.nb2gam.mixture.model(df,prior=cp,nrep=nrep,verbose=verbose,zero.count.threshold=zero.count.threshold, ...);
        m1 <- fit.nb2gth.mixture.model(df,prior=cp,nrep=nrep,verbose=verbose,zero.count.threshold=zero.count.threshold, ...);
      }

      if(return.compressed.models) {
        v <- get.compressed.v1.model(m1);
        cl <- clusters(m1);
        rm(m1); gc();
        return(list(model=v,clusters=cl));
      }

      # otherwise try to reduce the size of a full model
      # reduce return size
      #m1@posterior <- lapply(m1@posterior,function(m) { rownames(m) <- NULL; return(m);})
      m1@posterior <- NULL;
      #rownames(m1@concomitant@x) <- NULL;
      m1@concomitant@x <- matrix();
      m1@model <- lapply(m1@model,function(mod) {
        mod@x <- matrix();
        mod@y <- matrix();
        #rownames(mod@x) <- NULL;
        #rownames(mod@y) <- NULL;
        return(mod);
      })

      # make a clean copy of the internal environment
      t.cleanenv <- function(comp) {
        el <- list2env(as.list(environment(comp@logLik), all.names=TRUE),parent=globalenv());
        ep <- list2env(as.list(environment(comp@predict), all.names=TRUE),parent=globalenv());
        pf <- get("predict",envir=el); environment(pf) <- ep;  assign("predict",pf,envir=el)
        pf <- get("predict",envir=ep); environment(pf) <- ep;  assign("predict",pf,envir=ep)

        pf <- get("logLik",envir=el); environment(pf) <- el;  assign("logLik",pf,envir=el)
        pf <- get("logLik",envir=ep); environment(pf) <- el;  assign("logLik",pf,envir=ep)
  
        environment(comp@logLik) <- el;
        environment(comp@predict) <- ep;
        comp
      }
      m1@components <- lapply(m1@components,function(cl) lapply(cl,t.cleanenv))
      
      
      
      # clean up the formula environment (was causing multithreading problems)
      rm(list=ls(env=attr(m1@concomitant@formula,".Environment")),envir=attr(m1@concomitant@formula,".Environment"));
      gc();
      #rm(list=ls(env=attr(m1@formula,".Environment")),envir=attr(m1@formula,".Environment"));
      return(m1);
    },mc.cores=n.cores,mc.preschedule=F)

    # check if there were errors in the multithreaded portion
    lapply(1:length(ml),function(i) {
      if(class(ml[[i]])=="try-error") {
        message("ERROR encountered in building a model for cell ",ids[i],":");
        message(ml[[i]]);
        tryCatch(stop(paste("ERROR encountered in building a model for cell ",ids[i])),error=function(e) stop(e))
      }
    })
    
    if(save.plots) {
      # model fits
      #CairoPNG(filename=paste(group,"model.fits.png",sep="."),width=1024,height=300*length(ids));
      pdf(file=paste(group,"model.fits.pdf",sep="."),width=ifelse(old.fit,13,15),height=4)
      #l <- layout(matrix(seq(1,4*length(ids)),nrow=length(ids),byrow=T),rep(c(1,1,1,0.5),length(ids)),rep(1,4*length(ids)),FALSE);
      l <- layout(matrix(seq(1,4),nrow=1,byrow=T),rep(c(1,1,1,ifelse(old.fit,0.5,1)),1),rep(1,4),FALSE);
      par(mar = c(3.5,3.5,3.5,0.5), mgp = c(2.0,0.65,0), cex = 0.9);
      invisible(lapply(1:length(ids),function(i) {
        vi <- which(rowSums(vil[,-i,drop=F])>=min(length(ids)-1,min.nonfailed));
        df <- data.frame(count=counts[vi,ids[i]],fpm=rowMeans(t(t(counts[vi,ids[-i],drop=F])/(t.ls[-i]))))
        if(old.fit) {
          plot.nb2.mixture.fit(ml[[i]],df,en=ids[i],do.par=F,compressed.models=return.compressed.models);
        } else {
          #plot.nb2gam.mixture.fit(ml[[i]],df,en=ids[i],do.par=F);
          plot.nb2gth.mixture.fit(ml[[i]],df,en=ids[i],do.par=F,compressed.models=return.compressed.models);
        }
      }))
      dev.off();
    }
    names(ml) <- ids;

    return(ml);
    
  })
  
  if(return.compressed.models) {
    # make a joint model matrix
    jmm <- data.frame(do.call(rbind,lapply(mll,function(tl) do.call(rbind,lapply(tl,function(m) m$model)))));
    rownames(jmm) <- unlist(lapply(mll,names));
    # reorder in the original cell order
    attr(jmm,"groups") <- rep(names(mll),unlist(lapply(mll,length)))
    return(jmm);
  } else {
    return(mll);
  }
}

# V1 optimized methods

# gets an array summary of gam model structure (assumes a flat ifm list)
get.compressed.v1.models <- function(ifml) {
  data.frame(do.call(rbind,lapply(ifml,get.compressed.v1.model)))
}
# get a vector representation of a given model
get.compressed.v1.model <- function(m1) {
  v <- c(m1@concomitant@coef[,2], get("coef",environment(m1@components[[1]][[1]]@predict)),m1@components[[2]][[2]]@parameters$coef,get("theta",environment(m1@components[[2]][[2]]@predict)))
  names(v) <- c("conc.b","conc.a","fail.r","corr.b","corr.a","corr.theta")
  v
}

# calculates posterior matrices (log scale) for a set of ifm models
calculate.posterior.matrices <- function(dat,ifm,prior,n.cores=32,inner.cores=4,outer.cores=round(n.cores/inner.cores)) {
  marginals <- data.frame(fpm = 10^prior$x - 1); marginals$fpm[marginals$fpm<0] <- 0;
  lapply(ifm,function(group.ifm) {
    mclapply(sn(names(group.ifm)),function(nam) {
      df <- get.exp.logposterior.matrix(group.ifm[[nam]],dat[,nam],marginals,n.cores=inner.cores,grid.weight=prior$grid.weight)
      rownames(df) <- rownames(dat); colnames(df) <- as.character(prior$x);
      df
    },mc.cores=outer.cores)
  })
}

sample.posterior <- function(dat, ifm, prior, n.samples=1,n.cores=32) {
  marginals <- data.frame(fpm = 10^prior$x - 1);
  lapply(ifm,function(group.ifm) {
    mclapply(sn(names(group.ifm)),function(nam) {
      get.exp.sample(group.ifm[[nam]],dat[,nam],marginals,prior.x=prior$x,n=n.samples)
    },mc.cores=n.cores)
  })
}

# calculate joint posterior matrix for a given group of experiments
# lmatl - list of posterior matrices (log scale) for individual experiments
calculate.joint.posterior.matrix <- function(lmatl,n.samples=100,bootstrap=T,n.cores=15) {
  if(bootstrap) {
    jpl <- mclapply(1:n.cores,function(i) jpmatLogBoot(Matl=lmatl,Nboot=ceiling(n.samples/n.cores),Seed=i),mc.cores=n.cores)
    jpl <- Reduce("+",jpl);
    jpl <- jpl/rowSums(jpl);
  } else {
    jpl <- Reduce("+",lmatl);
    jpl <- exp(jpl-log.row.sums(jpl)); 
  }
  rownames(jpl) <- rownames(lmatl[[1]]);
  colnames(jpl) <- colnames(lmatl[[1]]);
  jpl
}

# calculate joint posterior of a group defined by a composition vector
# lmatll - list of posterior matrix lists (as obtained from calculate.posterior.matrices)
# composition - a named vector, indicating the number of samples that should be drawn from each element of lmatll to compose a group
calculate.batch.joint.posterior.matrix <- function(lmatll,composition,n.samples=100,n.cores=15) {
  # reorder composition vector to match lmatll names
  jpl <- mclapply(1:n.cores,function(i) jpmatLogBatchBoot(lmatll,composition[names(lmatll)],ceiling(n.samples/n.cores),i),mc.cores=n.cores)
  jpl <- Reduce("+",jpl);
  jpl <- jpl/rowSums(jpl);
  #jpl <- jpmatLogBatchBoot(lmatll,composition[names(lmatll)],n.samples,n.cores)
  rownames(jpl) <- rownames(lmatll[[1]][[1]]);
  colnames(jpl) <- colnames(lmatll[[1]][[1]]);
  jpl
}

# calculates the likelihood of expression difference based on
# two posterior matrices (not adjusted for prior)
calculate.ratio.posterior <- function(pmat1,pmat2,prior,n.cores=15,skip.prior.adjustment=F) {
  n <- length(prior$x)
  if(!skip.prior.adjustment) {
    pmat1 <- t(t(pmat1)*prior$y); pmat2 <- t(t(pmat2)*prior$y)
  }
  
  chunk <- function(x, n) split(x, sort(rank(x) %% n))
  if(n.cores>1) {
    x <- do.call(rbind,mclapply(chunk(1:nrow(pmat1),n.cores*5),function(ii) matSlideMult(pmat1[ii,,drop=F],pmat2[ii,,drop=F]),mc.cores=n.cores))
  } else {
    x <- matSlideMult(pmat1,pmat2);
  }
  x <- x/rowSums(x)
  
  #x <- cbind(do.call(cbind,mclapply(n:2,function(i) rowSums(pmat1[,1:(n-i+1),drop=F]*pmat2[,i:n,drop=F]),mc.cores=n.cores)),do.call(cbind,mclapply(1:n,function(i) rowSums(pmat1[,i:n,drop=F]*pmat2[,1:(n-i+1),drop=F]),mc.cores=n.cores)))
  rv <- seq(prior$x[1]-prior$x[length(prior$x)],prior$x[length(prior$x)]-prior$x[1],length=length(prior$x)*2-1)
  colnames(x) <- as.character(rv); rownames(x) <- rownames(pmat1)
  x
}

# quick utility function to get the difference Z score from the ratio posterior
get.ratio.posterior.Z.score <- function(rpost,min.p=1e-15) {
  rpost <- rpost+min.p; rpost <- rpost/rowSums(rpost);
  zi <- which.min(abs(as.numeric(colnames(rpost))))
  gs <- rowSums(rpost[,1:(zi-1),drop=F])
  zl <- qnorm(gs,lower.tail=T)
  zg <- qnorm(gs+rpost[,zi,drop=F],lower.tail=F)
  z <- ifelse(zl>zg,-1*zl,zg); 
}


# calculate a joint posterior matrix with bootstrap
jpmatLogBoot <- function(Matl, Nboot, Seed) {
	.Call("jpmatLogBoot", Matl, Nboot, Seed, PACKAGE = "scde")
}

# similar to the above, but compiles joint by sampling a pre-set
# number of different types (defined by Comp factor)
jpmatLogBatchBoot <- function(Matll, Comp, Nboot, Seed) {
	.Call("jpmatLogBatchBoot", Matll, Comp, Nboot, Seed, PACKAGE = "scde")
}

matSlideMult <- function(Mat1, Mat2) {
	.Call("matSlideMult", Mat1, Mat2, PACKAGE = "scde")
}


calculate.failure.p <- function(dat,ifm,n.cores=32) {
  lapply(ifm,function(group.ifm) {
    lapply(sn(names(group.ifm)),function(nam) {
      get.concomitant.prob(group.ifm[[nam]],counts=dat[,nam])
    })
  })
}

# calculate failure probabilities across all cells for a given set
# of levels (lfpm - log(fpm) vector for all genes
calculate.failure.lfpm.p <- function(lfpm,ifm,n.cores=32) {
  lapply(ifm,function(group.ifm) {
    lapply(sn(names(group.ifm)),function(nam) {
      get.concomitant.prob(group.ifm[[nam]],lfpm=lfpm)
    })
  })
}



# get expected fpm from counts
get.fpm.estimates <- function(m1,counts) {
  if(class(m1@components[[2]][[2]])=="FLXcomponentE") {
    # gam; do inverse interpolation
    b1 <- get("b1",envir=environment(m1@components[[2]][[2]]@predict))
    z <- approx(x=b1$fitted.values,y=b1$model$x,xout=counts,rule=1:2)$y
    z[is.na(z)] <- -Inf;
    z
  } else {
    # linear model
    par <- m1@components[[2]][[2]]@parameters;
    if(!is.null(par[["linear"]])) {
      log((counts-par$coef[[1]])/par$coef[[2]])
    } else {
      (log(counts)-par$coef[[1]])/par$coef[[2]]
    }
  }
}

##### INTERNAL FUNCTIONS

# clean up stale web server reference
.onAttach <- function(...) {
  if(exists("___scde.server",envir=globalenv())) {
    packageStartupMessage("scde: removing stale web server instance");
    rm("___scde.server",envir=globalenv());
  }
}

# rdf : count/fpm data frame
fit.nb2.mixture.model <- function(rdf,zero.count.threshold=10,prior=cbind(rdf$count<=zero.count.threshold,rdf$count>zero.count.threshold),nrep=3,iter=50,verbose=0, background.rate=0.1, ...) {
  #mo1 <- FLXMRnb2glmC(count~1,components=c(1),theta.range=c(0.5,Inf))
  #mo1 <- FLXMRglmCf(count~1,components=c(1),family="poisson",mu=0.01)
  #mo1 <- FLXMRglmC(count~1,components=c(1),family="poisson")
  mo1 <- FLXMRglmCf(count~1,family="poisson",components=c(1),mu=log(background.rate))
  mo2 <- FLXMRnb2glmC(count~1+I(log(fpm)),components=c(2),theta.range=c(0.5,Inf))

  m1 <- mc.stepFlexmix(count~1,data=rdf,k=2,model=list(mo1,mo2),control=list(verbose=verbose,minprior=0,iter=iter),concomitant=FLXPmultinom(~I(log(fpm))+1),cluster=prior,nrep=nrep, ...)

  # check if the theta was underfit
  if(get("theta",envir=environment(m1@components[[2]][[2]]@logLik))==0.5) {
    # refit theta
    sci <- clusters(m1)==2
    fit <- glm.nb.fit(m1@model[[2]]@x[sci,,drop=F],m1@model[[2]]@y[sci], weights=rep(1,sum(sci)), offset=c(),init.theta=0.5)
    assign("theta",value=fit$theta,envir=environment(m1@components[[2]][[2]]@logLik))
    m1@components[[2]][[2]]@parameters$coef <- fit$coefficients;
    assign("coef",value=fit$coefficients,envir=environment(m1@components[[2]][[2]]@logLik))
    message("WARNING: theta was underfit, new theta=",fit$theta);
  }

  return(m1);
}


fit.nb2gth.mixture.model <- function(rdf,zero.count.threshold=10,prior=cbind(rdf$count<=zero.count.threshold,rdf$count>zero.count.threshold),nrep=3,verbose=0 ,full.theta.range=c(1e-2,1e2), theta.fit.range=c(1e-4,1e4),theta.sp=1e-2,use.constant.theta.fit=F,iter=50) {
  #mo1 <- FLXMRglmC(count~1,components=c(1),family="poisson")
  mo1 <- FLXMRglmCf(count~1,family="poisson",components=c(1),mu=log(0.1))
  mo2 <- FLXMRnb2gthC(count~1+I(log(fpm)),components=c(2),full.theta.range=full.theta.range,theta.fit.range=theta.fit.range,theta.fit.sp=theta.sp,constant.theta=use.constant.theta.fit)
  m1 <- mc.stepFlexmix(count~1,data=rdf,k=2,model=list(mo1,mo2),control=list(verbose=verbose,minprior=0,iter=iter),concomitant=FLXPmultinom(~I(log(fpm))+1),cluster=prior,nrep=nrep)

  return(m1);
}


# rdf : count/fpm data frame
# en : experiment name for plotting
# n.zero.windows - number of windows to vizualize failure model fit
# m1 - fitted model
plot.nb2.mixture.fit <- function(m1,rdf,en,do.par=T,n.zero.windows=50,compressed.models=F) {
  #require(Cairo); require(RColorBrewer)
  if(do.par) {
    CairoPNG(filename=paste(en,"model.fit.png",sep="."),width=800,height=300)
    l <- layout(matrix(c(1:4),1,4,byrow=T),c(1,1,1,0.5),rep(1,4),FALSE);
    par(mar = c(3.5,3.5,3.5,0.5), mgp = c(2.0,0.65,0), cex = 0.9);
  }
  smoothScatter(log10(rdf$fpm+1),log10(rdf$count+1),xlab="expected FPM",ylab="observed counts",main=paste(en,"scatter",sep=" : "))
  
  plot(c(),c(),xlim=range(log10(rdf$fpm+1)),ylim=range(log10(rdf$count+1)),xlab="expected FPM",ylab="observed counts",main=paste(en,"components",sep=" : "));
  if(compressed.models) {
    vpi <- m1$clusters==1;
  } else {
    vpi <- clusters(m1)==1;
  }
  if(sum(vpi)>2){ 
    points(log10(rdf$fpm[vpi]+1),log10(rdf$count[vpi]+1),pch=".",col=densCols(log10(rdf$fpm[vpi]+1),log10(rdf$count[vpi]+1),colramp=colorRampPalette(brewer.pal(9, "Reds")[-(1:3)])),cex=2)
  }
  if(sum(!vpi)>2){ 
    points(log10(rdf$fpm[!vpi]+1),log10(rdf$count[!vpi]+1),pch=".",col=densCols(log10(rdf$fpm[!vpi]+1),log10(rdf$count[!vpi]+1),colramp=colorRampPalette(brewer.pal(9, "Blues")[-(1:3)])),cex=2)
    # show fit
    fpmo <- order(rdf$fpm[!vpi],decreasing=F);
    if(compressed.models) {
      #rf <- scde.failure.probability(data.frame(t(m1$model)),magnitudes=log(rdf$fpm))
      lines(log10(rdf$fpm[!vpi]+1)[fpmo],log10(exp(m1$model[["corr.a"]]*log(rdf$fpm[!vpi])[fpmo]+m1$model[["corr.b"]])+1))
    } else {
      lines(log10(rdf$fpm[!vpi]+1)[fpmo],log10(m1@components[[2]][[2]]@predict(cbind(1,log(rdf$fpm[!vpi])))+1)[fpmo],col=4)
    }
  }
  legend(x="topleft",col=c("red","blue"),pch=19,legend=c("failure component","correlated component"),bty="n",cex=0.9)
  
  # zero fit
  bw <- floor((dim(rdf)[1])/n.zero.windows)
  if(compressed.models) {
    rdf$cluster <- m1$clusters;
  } else {
    rdf$cluster <- clusters(m1);
  }
  rdf <- rdf[order(rdf$fpm,decreasing=F),]
  fdf <- data.frame(y=rowMeans(matrix(log10(rdf$fpm[1:(n.zero.windows*bw)]+1),ncol=bw,byrow=T)),zf=rowMeans(matrix(as.integer(rdf$cluster[1:(n.zero.windows*bw)]==1),ncol=bw,byrow=T)))
  plot(zf~y,fdf,ylim=c(0,1),xlim=range(na.omit(log10(rdf$fpm+1))),xlab="expected FPM",ylab="fraction of failures",main="failure model",pch=16,cex=0.5)
  ol <- order(rdf$fpm,decreasing=T);
  if(compressed.models) {
    fp <- scde.failure.probability(data.frame(t(m1$model)),magnitudes=log(rdf$fpm))
    lines(log10(rdf$fpm[ol]+1),fp[ol],col=2)
  } else {
    mt <- terms(m1@concomitant@formula,data=rdf)
    mf <- model.frame(delete.response(mt),data=rdf,na.action=NULL)
    cm0 <- exp(model.matrix(mt,data=mf) %*% m1@concomitant@coef);
    cm0 <- cm0/rowSums(cm0)
    lines(log10(rdf$fpm[ol]+1),cm0[ol,1],col=2)
  }
  
  
  # show thetas
  #tl <- c(fail=get("theta",envir=environment(m1@components[[1]][[1]]@logLik)),corr=get("theta",envir=environment(m1@components[[2]][[2]]@logLik)))
  if(compressed.models) {
    tl <- c(fail=c(),corr=m1$model[["corr.theta"]])
  } else {
    tl <- c(fail=c(0),corr=get("theta",envir=environment(m1@components[[2]][[2]]@logLik)))
  }
  barplot(tl,beside=T,las=2,col=c("dodgerblue1","indianred1"),ylab="magnitude",main="theta")
  box();
  abline(h=0)
  if(do.par) {   dev.off(); }
}



# same for gth fit
plot.nb2gth.mixture.fit <- function(m1,rdf,en,do.par=T,n.zero.windows=50,compressed.models=F) {
  #require(Cairo); require(RColorBrewer)
  if(do.par) {
    CairoPNG(filename=paste(en,"model.fit.png",sep="."),width=900,height=300)
    l <- layout(matrix(c(1:4),1,4,byrow=T),c(1,1,1,1),rep(1,4),FALSE);
    par(mar = c(3.5,3.5,3.5,0.5), mgp = c(2.0,0.65,0), cex = 0.9);
  }

  smoothScatter(log10(rdf$fpm+1),log10(rdf$count+1),xlab="expected FPM",ylab="observed counts",main=en)
  
  plot(c(),c(),xlim=range(log10(rdf$fpm+1)),ylim=range(log10(rdf$count+1)),xlab="expected FPM",ylab="observed counts",main="components");
  vpi <- clusters(m1)==1;
  if(sum(!vpi)>2){ 
    points(log10(rdf$fpm[!vpi]+1),log10(rdf$count[!vpi]+1),pch=".",col=densCols(log10(rdf$fpm[!vpi]+1),log10(rdf$count[!vpi]+1),colramp=colorRampPalette(brewer.pal(9, "Blues")[-(1:3)])),cex=2)

    # show gam fit (q1)
    q1 <- get("q1",envir=environment(m1@components[[2]][[2]]@predict))
    fpmo <- order(rdf$fpm[!vpi],decreasing=F)
    lines(log10(rdf$fpm[!vpi]+1)[fpmo],log10((predict.rq(q1,data.frame(x=rdf$fpm[!vpi])))+1)[fpmo],col=4)
    
  }
  if(sum(vpi)>2){ 
    points(log10(rdf$fpm[vpi]+1),log10(rdf$count[vpi]+1),pch=".",col=densCols(log10(rdf$fpm[vpi]+1),log10(rdf$count[vpi]+1),colramp=colorRampPalette(brewer.pal(9, "Reds")[-(1:3)])),cex=2)
  }

  legend(x="topleft",col=c("red","blue"),pch=19,legend=c("failure component","correlated component"),bty="n",cex=0.9)
  
  # zero fit
  bw <- floor((dim(rdf)[1])/n.zero.windows)
  rdf$cluster <- clusters(m1);
  rdf <- rdf[order(rdf$fpm,decreasing=F),]
  fdf <- data.frame(y=rowMeans(matrix(log10(rdf$fpm[1:(n.zero.windows*bw)]+1),ncol=bw,byrow=T)),zf=rowMeans(matrix(as.integer(rdf$cluster[1:(n.zero.windows*bw)]==1),ncol=bw,byrow=T)))
  plot(zf~y,fdf,ylim=c(0,1),xlim=range(na.omit(log10(rdf$fpm+1))),xlab="expected FPM",ylab="fraction of failures",main="failure model",pch=16,cex=0.5)
  mt <- terms(m1@concomitant@formula,data=rdf)
  mf <- model.frame(delete.response(mt),data=rdf,na.action=NULL)
  cm0 <- exp(model.matrix(mt,data=mf) %*% m1@concomitant@coef);
  cm0 <- cm0/rowSums(cm0)
  ol <- order(rdf$fpm,decreasing=T);
  lines(log10(rdf$fpm[ol]+1),cm0[ol,1],col=2)
  
  
  # show theta fit
  theta.fit <- get("theta.rb",envir=environment(m1@components[[2]][[2]]@predict))
  #theta.fit <- m1@components[[2]][[2]]@theta.fit
  mu <- log10(exp(theta.fit$model$"log(mu)"))
  muo <- order(mu,decreasing=F);
  smoothScatter(mu,-1*log10(theta.fit$model$te),xlab="expected FPM",ylab="log10[theta]",main="overdispersion",bandwidth=0.1)
  lines(mu[muo],(-1/log(10))*(mgcv::predict.gam(theta.fit))[muo],col=2,cex=2)
 
  if(do.par) {   dev.off(); }
}


## from nb2.crossmodels.r
mc.stepFlexmix <- function(..., nrep=5,mc.cores=nrep,return.all=F) {
  if(nrep==1) {
    return(flexmix(...))
  } else {
    ml <- mclapply(1:nrep,function(m) {
      x = try(flexmix(...))
    },mc.cores=mc.cores)
    if(return.all) { return(ml) }
    ml <- ml[unlist(lapply(ml,function(x) !is(x,"try-error")))]
    logLiks <- unlist(lapply(ml,logLik))
    ml[[which.max(logLiks)]];
  }
}


# df: count matrix
# xr: expression level for each row in the matrix
# ml: fitted model list for a replicate
get.rep.set.posteriors <- function(xr,df,ml,rescale=T) {
  pl <- do.call(cbind,lapply(1:length(ml),function(i) {
    edf <- data.frame(y=df[,i],xr=xr)
    m1 <- ml[[i]];
    x <- FLXgetModelmatrix(m1@model[[1]],edf,m1@model[[1]]@formula);
    #cx <- FLXgetModelmatrix(m1@concomitant,edf,m1@concomitant@formula)
    cm <- (1/(1+exp(-1*(x@x %*% m1@concomitant@coef[,-1]))))
    p1 <- (1-cm)*exp(FLXdeterminePostunscaled(x,m1@components[[1]]))
    p2 <- cm*exp(FLXdeterminePostunscaled(x,m1@components[[2]]))
    tpr <- as.numeric(p1+p2);
    if(rescale) {tpr <- tpr/sum(tpr) }
    return(tpr);
  }))
  colnames(pl) <- names(ml);

  return(pl);
}

# evaluates likelihood for a list of models and a set of
# corresponding counts
# ml - model list
# counts - observed count matrix corresponding to the models
# marginals - marginal info, to which model-specific count will be appended
get.rep.set.general.model.posteriors <- function(ml,counts,marginals,grid.weight=rep(1,nrow(marginals)),rescale=T,min.p=0) {
  pl <- do.call(cbind,lapply(1:length(ml),function(i) {
    marginals$count <- counts[,i];
    rowSums(get.component.model.lik(ml[[i]],marginals))+min.p
  }))
  if(rescale) {
    #pl <- pl*grid.weight+min.p;
    pl <- t(t(pl)/colSums(pl))
  }
  colnames(pl) <- names(ml);
  return(pl);
}

get.rep.set.general.model.logposteriors <- function(ml,counts,marginals,grid.weight=rep(1,nrow(marginals)),rescale=T) {
  pl <- do.call(rbind,lapply(1:length(ml),function(i) {
    marginals$count <- counts[,i];
    log.row.sums(get.component.model.loglik(ml[[i]],marginals))
  }))
  if(rescale) {
    pl <- pl-log.row.sums(pl)
  }
  rownames(pl) <- names(ml);
  return(t(pl));
}

# evaluate likelihood on a mixed model with a binomial concomitant
# returns posterior probability for each component: rowSums(return) gives
# total likelihood. (note it's not on a log scale!)
get.component.model.lik <- function(m1,newdata) {
  # core models
  cp <- exp(do.call("+",lapply(seq_along(m1@model),function(i) {
    y <- posterior(m1@model[[i]],newdata,lapply(m1@components,"[[",i))
  })))
  # concomitant

  # no groups!
  mt <- terms(m1@concomitant@formula,data=newdata)
  mf <- model.frame(delete.response(mt),data=newdata,na.action=NULL)
  cm0 <- exp(model.matrix(mt,data=mf) %*% m1@concomitant@coef);
  cm0 <- cm0/rowSums(cm0);
  cm0[!is.finite(cm0)] <- 1; 
  return(cp*cm0);
}

# same as above, but keeping log resolution
get.component.model.loglik <- function(m1,newdata) {
  # core models
  cp <- do.call("+",lapply(seq_along(m1@model),function(i) {
    y <- posterior(m1@model[[i]],newdata,lapply(m1@components,"[[",i))
  }))
  cp[!is.finite(cp)] <- sign(cp[!is.finite(cp)])*.Machine$double.xmax
  # concomitant
  # no groups!
  mt <- terms(m1@concomitant@formula,data=newdata)
  mf <- model.frame(delete.response(mt),data=newdata,na.action=NULL)
  cm0 <- model.matrix(mt,data=mf) %*% m1@concomitant@coef;
  cm0[is.nan(cm0)] <- 1;
  cm0[!is.finite(cm0)] <- sign(cm0[!is.finite(cm0)])*.Machine$double.xmax

  cm0 <- cm0-log.row.sums(cm0);
  return(cp+cm0);
}


# returns a matrix of posterior values, with rows corresponding to genes, and
# columns to marginal values (prior fpkm grid)
# m1 - model
# counts - vector of per-gene counts for a given experiment
# marginals - fpm data frame
get.exp.posterior.matrix <- function(m1,counts,marginals,grid.weight=rep(1,nrow(marginals)),rescale=T,n.cores=32,min.p=0) {
  uc <- unique(counts);
  #message(paste("get.exp.posterior.matrix() :",round((1-length(uc)/length(counts))*100,3),"% savings"));
  cat(".");
  df <- do.call(rbind,mclapply(uc,function(x) { 
    rowSums(get.component.model.lik(m1,cbind(marginals,count=rep(x,nrow(marginals)))))+min.p;
  },mc.cores=n.cores,mc.preschedule=T));
  if(rescale) {
    #df <- t(t(df)*grid.weight)+min.p;
    df <- df/rowSums(df)
  }
  df <- df[match(counts,uc),,drop=F]
  rownames(df) <- names(counts);
  df
}

get.exp.logposterior.matrix <- function(m1,counts,marginals,grid.weight=rep(1,nrow(marginals)),rescale=T,n.cores=32) {
  uc <- unique(counts);
  #message(paste("get.exp.logposterior.matrix() :",round((1-length(uc)/length(counts))*100,3),"% savings"));
  cat(".");
  df <- do.call(rbind,mclapply(uc,function(x) {
    log.row.sums(get.component.model.loglik(m1,cbind(marginals,count=rep(x,nrow(marginals)))))
  },mc.cores=n.cores,mc.preschedule=T));
  if(rescale) {
    df <- df-log.row.sums(df)
  }
  df <- df[match(counts,uc),,drop=F]
  rownames(df) <- names(counts);
  df
}

# similar to get.exp.posterior.matrix(), but returns inverse ecdf list
# note that x must be supplied
get.exp.posterior.samples <- function(pmatl,prior,n.samples=1,n.cores=32) {
  sl <- mclapply(1:length(pmatl),function(i) t(apply(pmatl[[i]],1,function(d) approxfun(cumsum(d),prior$x,rule=2)(runif(n.samples)))),mc.cores=n.cores)
  names(sl) <- names(pmatl);
  sl
}
# similar to get.exp.posterior.matrix(), but returns inverse ecdf list
# note that x must be supplied
get.exp.sample <- function(m1,counts,marginals,prior.x,n,rescale=T) {
  do.call(rbind,mclapply(counts,function(x) { 
    tpr <- log.row.sums(get.component.model.loglik(m1,cbind(marginals,count=rep(x,nrow(marginals)))));
    if(rescale)  { tpr <- exp(tpr-max(tpr)); tpr <- tpr/sum(tpr) }; 
    return(approxfun(cumsum(tpr),prior.x,rule=2)(runif(n)))
  },mc.cores=10))
}



# gets a probability of failed detection for a given observation
# optional vector of fpm values (log) can be supplied to evaluate mixing probability
# at a point other than MLE fpm
get.concomitant.prob <- function(m1,counts=NULL,lfpm=NULL) {
  if(is.null(lfpm)) {
    lfpm <- get.fpm.estimates(m1,counts)
  }
  newdata <- data.frame(fpm=exp(lfpm))
  mt <- terms(m1@concomitant@formula,data=newdata)
  mf <- model.frame(delete.response(mt),data=newdata,na.action=NULL)
  cm0 <- exp(model.matrix(mt,data=mf) %*% m1@concomitant@coef);
  cm0[is.nan(cm0)] <- 1;
  cm0 <- cm0/rowSums(cm0)
  return(as.numeric(cm0[,1]))
}


# copied from flexmix
log.row.sums <- function(m) {
  M <- m[cbind(seq_len(nrow(m)), max.col(m,ties.method="first"))]; # "random" doesnt' work!
  M + log(rowSums(exp(m - M)))
}


### from nb1gml.R

# nb2 glm implementation
setClass("FLXMRnb2glm", contains = "FLXMRglm",package="flexmix")

FLXMRnb2glm <- function(formula = . ~ .,  offset=NULL, init.theta=NULL, theta.range=c(0,1e3), ...) {
  #require(MASS);
    family <- "negative.binomial";
    glmrefit <- function(x, y, w) {
      #message("FLXRnb2glm:refit:nb2")
      fit <- c(glm.nb.fit(x, y, weights=w, offset=offset,init.theta=init.theta,theta.range=theta.range),
               list(call = sys.call(), offset = offset,control = eval(formals(glm.fit)$control),method = "glm.fit")
               )
      fit$df.null <- sum(w) + fit$df.null - fit$df.residual - fit$rank
      fit$df.residual <- sum(w) - fit$rank
      fit$x <- x
      fit
    }
                
    z <- new("FLXMRnb2glm", weighted=TRUE, formula=formula,
             name="FLXMRnb2glm", offset = offset,
             family=family, refit=glmrefit)
    z@preproc.y <- function(x) {
      if (ncol(x) > 1)
        stop(paste("for the", family, "family y must be univariate"))
      x
    }


    z@defineComponent <- expression({
      predict <- function(x, ...) {
        dotarg = list(...)
        #message("FLXRnb2glm:predict:nb2")
        if("offset" %in% names(dotarg)) offset <- dotarg$offset
        p <- x%*%coef
        if (!is.null(offset)) p <- p + offset
        negative.binomial(theta)$linkinv(p)
      }
      logLik <- function(x, y, ...) {
        r <- dnbinom(y, size=theta,mu=predict(x, ...), log=TRUE)
        #message(paste("FLXRnb2glm:loglik:nb2",theta))
        return(r);
      }
      
      new("FLXcomponent",
          parameters=list(coef=coef),
          logLik=logLik, predict=predict,
          df=df)
    })
    
    z@fit <- function(x, y, w){
      #message("FLXRnb2glm:fit:nb2")
      w[y<=1] <- w[y<=1]/1e6; # focus the fit on non-failed genes
      fit <- glm.nb.fit(x, y, weights=w, offset=offset,init.theta=init.theta,theta.range=theta.range)
      # an ugly hack to restrict to non-negative slopes
      cf <- coef(fit); if(cf[2]<0) { cf <- c(mean(y*w)/sum(w),0) }
      with(list(coef = cf, df = ncol(x), theta=fit$theta, offset=offset),
           eval(z@defineComponent))
    }

    z
  
}

# component-specific version of the nb2glm
# nb2 glm implementation
setClass("FLXMRnb2glmC", representation(vci="ANY"), contains = "FLXMRnb2glm",package="flexmix")

# components is used to specify the indecies of the components on which likelihood will be
# evlauated. Others will return as loglik of 0
FLXMRnb2glmC <- function(... , components=NULL) {
    #require(MASS);
    z <- new("FLXMRnb2glmC", FLXMRnb2glm(...),vci=components)
    z
}



# nb2 glm implementation
setClass("FLXMRnb2gam", contains = "FLXMRglm",package="flexmix")

setClass("FLXcomponentE",
         representation(refitTheta="function",
                        theta.fit="ANY"),
         contains = "FLXcomponent",package="flexmix")



# nb2 implementation with a simple trimmed-mean/median slope, and a gam theta fit
setClass("FLXMRnb2gth", contains = "FLXMRglm",package="flexmix")

FLXMRnb2gth <- function(formula = . ~ .,  offset=NULL, full.theta.range=c(1e-3,1e3), theta.fit.range=full.theta.range*c(1e-1,1e1),theta.fit.sp=c(-1), constant.theta=F, ...) {
    
    family <- "negative.binomial";
    glmrefit <- function(x, y, w) {
      message("ERROR: FLXRnb2gth:glmrefit: NOT IMPLEMENTED");
      return(NULL);
    }
                
    z <- new("FLXMRnb2gth", weighted=TRUE, formula=formula,
             name="FLXMRnb2gth", offset = offset,
             family=family, refit=glmrefit)
    z@preproc.y <- function(x) {
      if (ncol(x) > 1)
        stop(paste("for the", family, "family y must be univariate"))
      x
    }

    z@defineComponent <- expression({
      predict <- function(x, ...) {
        dotarg = list(...)
        #message("FLXRnb2gth:predict:nb2")
        (predict.rq(q1,data.frame(x=exp(x[,2]))))
      }
      logLik <- function(x, y, ...) {
        dotarg = list(...)
        #message("FLXRnb2gth:logLik")        
        # fit mu
        newmu <- (predict.rq(q1,data.frame(x=exp(x[,2]))))
        # fit theta
        vix <- x[,2] >= theta.rb$x.range[1] & x[,2] <= theta.rb$x.range[2];
        newth <- rep(NA,length(vix));
        if(any(vix)) {
          newth[vix] <- exp(mgcv::predict.gam(theta.rb,data.frame(mu=exp(x[vix,2]))))
        }
        # fix extrapolation points
        newth[x[,2] >= theta.rb$x.range[2]] <- theta.rb$y.end;
        newth[x[,2] <= theta.rb$x.range[1]] <- theta.rb$y.start;

        newth[newth < 1/full.theta.range[2]] <-  1/full.theta.range[2]
        newth[newth > 1/full.theta.range[1]] <-  1/full.theta.range[1]
        # evaluate NB
        r <- dnbinom(y, size=1/newth,mu=newmu, log=TRUE)
      }
      
      new("FLXcomponent",
          # note don't forget to change get.fpm.estimates if the model is altered
          #parameters=list(coef=q1$coefficients,linear=T),#
          parameters=list(coef=c(0,q1$coefficients[1]),linear=T),
          logLik=logLik, predict=predict, df=df)
    })
    
    z@fit <- function(x, y, w){
      fpm <- exp(x[,2])+1
      # quantile regression fit 
      df <- data.frame(x=fpm,y=y)
      q1 <- rq(as.formula("y~0+x"),weights=w,data=df,subset=(y>1))
      # adjust the slope - for some reason, doesn't fit the actual median ...
      #q1$coefficients[1] <- weighted.median.scde(df$y/df$x,w=w*log(df$y+1))

      # poisson fit for the slope
      #q1 <- glm(y~0+log(x),weights=w,family=poisson(link="log"),data=df,subset=(y>1))
      
      

      
      #df <- data.frame(x=rdf$fpm,y=rdf$count)
      #w <- ifelse(df$y>0,1-1e-3,1e-3)
      #smoothScatter(log(df$x+1),log(df$y+1))
      #points(log(df$x[w<0.5]),log(df$y[w<0.5]+1))
      #points(log(df$x+1),log(predict.rq(q1,df)+1),pch=".",col=2)
      #n1 <- glm(y~log(x),weights=w,family=poisson(link="log"),data=df)
      #p1 <- glm(y~0+log(x),weights=w*sqrt(df$x),family=poisson(link="log"),data=df)
      #points(log(df$x+1),predict.glm(p1),pch=".",col=4)
      #nq1 <- rq(y~x,weights=w,data=df,subset=y>1)
      #points(log(df$x+1),log(predict.rq(nq1,df)+1),pch=".",col=3)
      #nb1 <- mgcv::gam(y~s(x),weights=w,family=poisson(),sp=c(-1),optimizer="perf",data=df)
      #b1 <- mgcv::gam(y~s(log(x)),weights=w,family=negbin(initial.theta.range),sp=fit.sp,optimizer="perf",data=df)
      #points(log(df$x+1),mgcv::predict.gam(nb1),pch=".",col="pink")
      
      #browser()
      # gamma fit
      x <- na.omit(data.frame(mu=fpm,te=((df$y-(predict.rq(q1)))^2-fpm+10)/fpm^2)[df$y>1,])
      x$te[x$te <= 1/theta.fit.range[2]] <- 1/theta.fit.range[2]
      x$te[x$te > 1/theta.fit.range[1]] <- 1/theta.fit.range[1]
      
      if(constant.theta) {
        theta.rb <- mgcv::gam(as.formula("te~1"),family=Gamma(link="log"),data=x)
        theta.rb$model$"log(mu)" <- log(x$mu)
      } else {
        theta.rb <- mgcv::gam(as.formula("te~s(log(mu))"),sp=theta.fit.sp,family=Gamma(link="log"),data=x)
      }

      # append range and start/end values to preclude whild extrapolations later
      theta.rb$x.range <- log(range(x$mu))
      omu <- order(x$mu,decreasing=F)
      theta.rb$y.start <- theta.rb$fitted.values[omu[1]]
      theta.rb$y.end <- theta.rb$fitted.values[omu[length(omu)]]

      with(list(q1 = q1,theta.rb=theta.rb,full.theta.range=full.theta.range,df=ncol(x),offset=offset),
           eval(z@defineComponent))
    }

    z
  
}

# component-specific version of the nb2gth
# nb2 gam implementation
setClass("FLXMRnb2gthC", representation(vci="ANY"), contains = "FLXMRnb2gth",package="flexmix")

# components is used to specify the indecies of the components on which likelihood will be
# evlauated. Others will return as loglik of 0
FLXMRnb2gthC <- function(... , components=NULL) {
  #require(mgcv);
  z <- new("FLXMRnb2gthC", FLXMRnb2gth(...),vci=components)
  z
}



setMethod("FLXdeterminePostunscaled", signature(model = "FLXMRnb2glmC"), function(model, components, ...) {
  if(is.null(model@vci)) {
    #message("FLXMRnb2glmC:FLXdeterminePostunscaled - applying to all components");
    m <- matrix(sapply(components, function(x) x@logLik(model@x, model@y)), nrow = nrow(model@y))
  } else {
    #message(paste("FLXMRnb2glmC:FLXdeterminePostunscaled - applying to components",paste(model@vci,collapse=" ")));
    m <- matrix(do.call(cbind,lapply(seq_along(components),function(i) {
      if(i %in% model@vci) {
        components[[i]]@logLik(model@x, model@y)
      } else {
        rep(0,nrow(model@y))
      }
    })), nrow = nrow(model@y))
 }
})

setMethod("FLXmstep", signature(model = "FLXMRnb2glmC"), function(model, weights, ...) {
  # make up a dummy component return
  coef <- rep(0, ncol(model@x))
  names(coef) <- colnames(model@x)
  control <- eval(formals(glm.fit)$control);
  comp.1 <- with(list(coef = coef, df = 0, offset = NULL,
                      family = model@family), eval(model@defineComponent))

  # iterate over components
  unlist(lapply(1:dim(weights)[2],function(i) {
    if(i %in% model@vci) {
      #message(paste("FLXMRnb2glmC:FLXmstep - running m-step for component",i)); 
      FLXmstep(as(model, "FLXMRnb2glm"), weights[, i, drop=FALSE])
    } else {
      #message(paste("FLXMRnb2glmC:FLXmstep - dummy return for component",i)); 
      list(comp.1);
    }
  }),recursive=F)
})

# same for gth
setMethod("FLXdeterminePostunscaled", signature(model = "FLXMRnb2gthC"), function(model, components, ...) {
  if(is.null(model@vci)) {
    #message("FLXMRnb2gthC:FLXdeterminePostunscaled - applying to all components");
    m <- matrix(sapply(components, function(x) x@logLik(model@x, model@y)), nrow = nrow(model@y))
  } else {
    #message(paste("FLXMRnb2gthC:FLXdeterminePostunscaled - applying to components",paste(model@vci,collapse=" ")));
    m <- matrix(do.call(cbind,lapply(seq_along(components),function(i) {
      if(i %in% model@vci) {
        components[[i]]@logLik(model@x, model@y)
      } else {
        rep(0,nrow(model@y))
      }
    })), nrow = nrow(model@y))
 }
})

setMethod("FLXmstep", signature(model = "FLXMRnb2gthC"), function(model, weights, ...) {
  # make up a dummy component return
  coef <- rep(0, ncol(model@x))
  names(coef) <- colnames(model@x)
  control <- eval(formals(glm.fit)$control);
  comp.1 <- with(list(q1=list(coefficients=c(1)), coef = coef, df = 0, offset = NULL,
                      family = model@family), eval(model@defineComponent))

  # iterate over components
  unlist(lapply(1:dim(weights)[2],function(i) {
    if(i %in% model@vci) {
      #message(paste("FLXMRnb2gthC:FLXmstep - running m-step for component",i)); 
      FLXmstep(as(model, "FLXMRnb2gth"), weights[, i, drop=FALSE])
    } else {
      #message(paste("FLXMRnb2gthC:FLXmstep - dummy return for component",i)); 
      list(comp.1);
    }
  }),recursive=F)
})




# mu-fixed component-specific version of the nb2glm
# nb2 glm implementation
setClass("FLXMRnb2glmCf", representation(mu="numeric"), contains = "FLXMRnb2glmC",package="flexmix")

FLXMRnb2glmCf <- function(mu=0, ...) {
    #require(MASS);
    z <- new("FLXMRnb2glmCf", FLXMRnb2glmC(...),mu=mu)
    z
}

setMethod("FLXmstep", signature(model = "FLXMRnb2glmCf"), function(model, weights, ...) {
  # make up a dummy component return
  coef <- rep(0, ncol(model@x))
  names(coef) <- colnames(model@x)
  control <- eval(formals(glm.fit)$control);
  comp.1 <- with(list(coef = coef, df = 0, offset = NULL,
                      family = model@family), eval(model@defineComponent))

  # iterate over components
  unlist(lapply(1:dim(weights)[2],function(i) {
    if(i %in% model@vci) {
      # determine theta for the supported component
      s.coef <- c(model@mu, rep(0, ncol(model@x)-1))
      names(s.coef) <- colnames(model@x)
      s.control <- eval(formals(glm.fit)$control);
      s.th <- theta.md(y=model@y[,1],mu=rep(1,length(model@y)),dfr=sum(weights[,i]), weights=weights[,i],limit=1e3)
      #if(th>10) browser();
      #message(paste("FLXRzinb2glm:FLXmstep: i=",i,"; theta =",s.th))
      s.comp <- with(list(coef = s.coef, df = 0, offset = NULL,theta=s.th,family = model@family), eval(model@defineComponent));
      list(s.comp)
    } else {
      #message(paste("FLXMRnb2glmC:FLXmstep - dummy return for component",i)); 
      list(comp.1);
    }
  }),recursive=F)
})



# component-specific version of the nb2glm
# nb2 glm implementation
setClass("FLXMRglmC", representation(vci="ANY"), contains = "FLXMRglm",package="flexmix")

# components is used to specify the indecies of the components on which likelihood will be
# evlauated. Others will return as loglik of 0
FLXMRglmC <- function(... , components=NULL) {
  #require(MASS);
    z <- new("FLXMRglmC", FLXMRglm(...),vci=components)
    z
}

setMethod("FLXdeterminePostunscaled", signature(model = "FLXMRglmC"), function(model, components, ...) {
  if(is.null(model@vci)) {
    #message("FLXMRnb2glmC:FLXdeterminePostunscaled - applying to all components");
    m <- matrix(sapply(components, function(x) x@logLik(model@x, model@y)), nrow = nrow(model@y))
  } else {
    #message(paste("FLXMRnb2glmC:FLXdeterminePostunscaled - applying to components",paste(model@vci,collapse=" ")));
    m <- matrix(do.call(cbind,lapply(seq_along(components),function(i) {
      if(i %in% model@vci) {
        components[[i]]@logLik(model@x, model@y)
      } else {
        rep(0,nrow(model@y))
      }
    })), nrow = nrow(model@y))
  }
  #message("FLXMRnb2glmC:FLXdeterminePostunscaled : ")
  #message(m);
  #browser()
  m
})

setMethod("FLXmstep", signature(model = "FLXMRglmC"), function(model, weights, ...) {
  # make up a dummy component return
  coef <- rep(0, ncol(model@x))
  names(coef) <- colnames(model@x)
  control <- eval(formals(glm.fit)$control);
  comp.1 <- with(list(coef = coef, df = 0, offset = NULL,
                      family = model@family), eval(model@defineComponent))

  # iterate over components
  unlist(lapply(1:dim(weights)[2],function(i) {
    if(i %in% model@vci) {
      #message(paste("FLXMRglmC:FLXmstep - running m-step for component",i)); 
      FLXmstep(as(model, "FLXMRglm"), weights[, i, drop=FALSE])
    } else {
      #message(paste("FLXMRglmC:FLXmstep - dummy return for component",i)); 
      list(comp.1);
    }
  }),recursive=F)
})



# mu-fixed version
setClass("FLXMRglmCf", representation(mu="numeric"), contains = "FLXMRglmC",package="flexmix")

FLXMRglmCf <- function(... , family = c("binomial", "poisson"),mu=0) {
  #require(MASS);
    family <- match.arg(family)
    z <- new("FLXMRglmCf", FLXMRglmC(...,family=family),mu=mu)
    z
}

setMethod("FLXmstep", signature(model = "FLXMRglmCf"), function(model, weights, ...) {
  # make up a dummy component return
  coef <- c(model@mu,rep(0,ncol(model@x)-1))
  names(coef) <- colnames(model@x)
  control <- eval(formals(glm.fit)$control);
  comp.1 <- with(list(coef = coef, df = 0, offset = NULL,
                      family = model@family), eval(model@defineComponent))

  # iterate over components
  unlist(lapply(1:dim(weights)[2],function(i) {
    list(comp.1);
  }),recursive=F)
})

# variation of negative.binomial family that keeps theta value accessible
negbin.th <- function (theta = stop("'theta' must be specified"), link = "log") 
{
    linktemp <- substitute(link)
    if (!is.character(linktemp)) 
        linktemp <- deparse(linktemp)
    if (linktemp %in% c("log", "identity", "sqrt")) 
        stats <- make.link(linktemp)
    else if (is.character(link)) {
        stats <- make.link(link)
        linktemp <- link
    }
    else {
        if (inherits(link, "link-glm")) {
            stats <- link
            if (!is.null(stats$name)) 
                linktemp <- stats$name
        }
        else stop(linktemp, " link not available for negative binomial family; available links are \"identity\", \"log\" and \"sqrt\"")
    }
    .Theta <- theta
    env <- new.env(parent = .GlobalEnv)
    assign(".Theta", theta, envir = env)
    variance <- function(mu) mu + mu^2/.Theta
    validmu <- function(mu) all(mu > 0)
    dev.resids <- function(y, mu, wt) 2 * wt * (y * log(pmax(1, 
        y)/mu) - (y + .Theta) * log((y + .Theta)/(mu + .Theta)))
    aic <- function(y, n, mu, wt, dev) {
        term <- (y + .Theta) * log(mu + .Theta) - y * log(mu) + 
            lgamma(y + 1) - .Theta * log(.Theta) + lgamma(.Theta) - 
            lgamma(.Theta + y)
        2 * sum(term * wt)
    }
    initialize <- expression({
        if (any(y < 0)) stop("negative values not allowed for the negative binomial family")
        n <- rep(1, nobs)
        mustart <- y + (y == 0)/6
    })
    simfun <- function(object, nsim) {
        ftd <- fitted(object)
        val <- rnegbin(nsim * length(ftd), ftd, .Theta)
    }
    environment(variance) <- environment(validmu) <- environment(dev.resids) <- environment(aic) <- environment(simfun) <- env
    famname <- paste("Negative Binomial(", format(round(theta, 
        4)), ")", sep = "")
    structure(list(family = famname, link = linktemp, linkfun = stats$linkfun, 
        linkinv = stats$linkinv, variance = variance, dev.resids = dev.resids, 
        aic = aic, mu.eta = stats$mu.eta, initialize = initialize, 
        validmu = validmu, valideta = stats$valideta, simulate = simfun,theta=theta), 
        class = "family")
}


# .fit version of the glm.nb
glm.nb.fit <- function(x,y,weights=rep(1,nobs),control=list(trace=0,maxit=20),offset=rep(0,nobs),etastart=NULL,start=NULL,mustart=NULL,init.theta=NULL,link=log, method="glm.fit", intercept=T, theta.range=c(0,1e5), ...) {
  method <- "custom.glm.fit";
  #require(MASS);
  loglik <- function(n, th, mu, y, w) sum(w * (lgamma(th + 
        y) - lgamma(th) - lgamma(y + 1) + th * log(th) + y * 
        log(mu + (y == 0)) - (th + y) * log(th + mu)))
    link <- substitute(link)

  Call <- match.call()
  control <- do.call("glm.control", control)
  n <- length(y);
  # family for the initial guess
  fam0 <- if (missing(init.theta) | is.null(init.theta)) 
    do.call("poisson", list(link = link))
  else
    do.call("negative.binomial", list(theta = init.theta,link = link))

  # fit function
  if (!missing(method)) {
    #message(paste("glm.nb.fit: method=",method))
    if (!exists(method, mode = "function")) 
      stop("unimplemented method: ", sQuote(method))
    glm.fitter <- get(method)
  }
  else {
    #message("glm.nb.fit: using default glm.fit")
    method <- "glm.fit"
    glm.fitter <- stats::glm.fit
    #glm.fitter <- custom.glm.fit
  }
  
  if (control$trace > 1) {
    message("Initial fit:")
  }
  fit <- glm.fitter(x = x, y = y, weights = weights, start = start, etastart = etastart,mustart = mustart, offset = offset, family = fam0, control = control,intercept=intercept)
  class(fit) <- c("glm", "lm")
  
  mu <- fit$fitted.values
  th <- as.vector(theta.ml(y, mu, sum(weights), weights, limit = control$maxit,trace = control$trace > 2))
  if(!is.null(theta.range)) {
    if(th<theta.range[1]) {
      if (control$trace > 1) 
        message("adjusting theta from ",signif(th)," to ",signif(theta.range[1])," to fit the specified range")
      th <- theta.range[1];
    } else if(th>theta.range[2]) {
      if (control$trace > 1) 
        message("adjusting theta from ",signif(th)," to ",signif(theta.range[2])," to fit the specified range")
      th <- theta.range[2];
    }
  }
  if (control$trace > 1) 
        message("Initial value for theta:", signif(th))
  fam <- do.call("negative.binomial", list(theta = th, link = link))
  iter <- 0
  d1 <- sqrt(2 * max(1, fit$df.residual))
  d2 <- del <- 1
  g <- fam$linkfun
  Lm <- loglik(n, th, mu, y, weights)
  Lm0 <- Lm + 2 * d1
  while ((iter <- iter + 1) <= control$maxit && (abs(Lm0 - Lm)/d1 + abs(del)/d2) > control$epsilon) {
    eta <- g(mu)
    fit <- glm.fitter(x = x, y = y, weights = weights, etastart = eta,offset = offset, family = fam, control = list(maxit = control$maxit*10, epsilon = control$epsilon, trace = control$trace > 1), intercept = intercept)
    t0 <- th
    th <- theta.ml(y, mu, sum(weights), weights, limit = control$maxit, trace = control$trace > 2)
    if(!is.null(theta.range)) {
      if(th<theta.range[1]) {
        if (control$trace > 1) 
          message("adjusting theta from ",signif(th)," to ",signif(theta.range[1])," to fit the specified range")
        th <- theta.range[1];
      } else if(th>theta.range[2]) {
        if (control$trace > 1) 
          message("adjusting theta from ",signif(th)," to ",signif(theta.range[2])," to fit the specified range")
        th <- theta.range[2];
      }
    }
    fam <- do.call("negative.binomial", list(theta = th, link = link))
    mu <- fit$fitted.values
    del <- t0 - th
    Lm0 <- Lm
    Lm <- loglik(n, th, mu, y, weights)
    if (control$trace) {
      Ls <- loglik(n, th, y, y, weights)
      Dev <- 2 * (Ls - Lm)
      message("Theta(", iter, ") =", signif(th), ", 2(Ls - Lm) =",  signif(Dev))
    }
  }
  if (!is.null(attr(th, "warn"))) 
    fit$th.warn <- attr(th, "warn")
  if (iter > control$maxit) {
    warning("alternation limit reached")
    fit$th.warn <- gettext("alternation limit reached")
  }
  if (length(offset) && intercept) {
    null.deviance <- if ("(Intercept)" %in% colnames(x)) 
      glm.fitter(x[, "(Intercept)", drop = FALSE], y, weights=weights, offset = offset, family = fam, control = list(maxit = control$maxit*10, epsilon = control$epsilon, trace = control$trace >  1), intercept = TRUE)$deviance
    else
      fit$deviance
    fit$null.deviance <- null.deviance
  }
  class(fit) <- c("negbin.th", "glm", "lm")
  Call$init.theta <- signif(as.vector(th), 10)
  Call$link <- link
  fit$call <- Call
  fit$x <- x
  fit$y <- y
  fit$theta <- as.vector(th)
  fit$SE.theta <- attr(th, "SE")
  fit$twologlik <- as.vector(2 * Lm)
  fit$aic <- -fit$twologlik + 2 * fit$rank + 2
  fit$method <- method
  fit$control <- control
  fit$offset <- offset
  fit
}


custom.glm.fit <- function (x, y, weights = rep(1, nobs), start = NULL, etastart = NULL, 
    mustart = NULL, offset = rep(0, nobs), family = gaussian(), 
    control = list(), intercept = TRUE,alpha=0) 
{
    control <- do.call("glm.control", control)
    x <- as.matrix(x)
    xnames <- dimnames(x)[[2L]]
    ynames <- if (is.matrix(y)) 
        rownames(y)
    else names(y)
    conv <- FALSE
    nobs <- NROW(y)
    nvars <- ncol(x)
    EMPTY <- nvars == 0
    if (is.null(weights)) 
        weights <- rep.int(1, nobs)
    if (is.null(offset)) 
        offset <- rep.int(0, nobs)
    variance <- family$variance
    linkinv <- family$linkinv
    if (!is.function(variance) || !is.function(linkinv)) 
        stop("'family' argument seems not to be a valid family object", 
            call. = FALSE)
    dev.resids <- family$dev.resids
    aic <- family$aic
    mu.eta <- family$mu.eta
    unless.null <- function(x, if.null) if (is.null(x)) 
        if.null
    else x
    valideta <- unless.null(family$valideta, function(eta) TRUE)
    validmu <- unless.null(family$validmu, function(mu) TRUE)
    if (is.null(mustart)) {
        eval(family$initialize)
    }
    else {
        mukeep <- mustart
        eval(family$initialize)
        mustart <- mukeep
    }
    if (EMPTY) {
        eta <- rep.int(0, nobs) + offset
        if (!valideta(eta)) 
            stop("invalid linear predictor values in empty model", 
                call. = FALSE)
        mu <- linkinv(eta)
        if (!validmu(mu)) 
            stop("invalid fitted means in empty model", call. = FALSE)
        dev <- sum(dev.resids(y, mu, weights))
        w <- ((weights * mu.eta(eta)^2)/variance(mu))^0.5
        residuals <- (y - mu)/mu.eta(eta)
        good <- rep(TRUE, length(residuals))
        boundary <- conv <- TRUE
        coef <- numeric(0L)
        iter <- 0L
    }
    else {
        coefold <- NULL
        eta <- if (!is.null(etastart)) 
            etastart
        else if (!is.null(start)) 
            if (length(start) != nvars) 
                stop(gettextf("length of 'start' should equal %d and correspond to initial coefs for %s", 
                  nvars, paste(deparse(xnames), collapse = ", ")), 
                  domain = NA)
            else {
                coefold <- start
                offset + as.vector(if (NCOL(x) == 1) 
                  x * start
                else x %*% start)
            }
        else family$linkfun(mustart)
        mu <- linkinv(eta)
        if (!(validmu(mu) && valideta(eta))) 
            stop("cannot find valid starting values: please specify some", 
                call. = FALSE)
        devold <- sum(dev.resids(y, mu, weights))
        boundary <- conv <- FALSE
        for (iter in 1L:control$maxit) {
            good <- weights > 0
            varmu <- variance(mu)[good]
            if (any(is.na(varmu))) 
                stop("NAs in V(mu)")
            if (any(varmu == 0)) 
                stop("0s in V(mu)")
            mu.eta.val <- mu.eta(eta)
            if (any(is.na(mu.eta.val[good]))) 
                stop("NAs in d(mu)/d(eta)")
            good <- (weights > 0) & (mu.eta.val != 0)
            if (all(!good)) {
                conv <- FALSE
                warning("no observations informative at iteration ", 
                  iter)
                break
            }
            z <- (eta - offset)[good] + (y - mu)[good]/mu.eta.val[good]
            #z <- (eta - offset)[good] + (family$linkfun(y[good]) - family$linkfun(mu[good]))/family$linkfun(mu.eta.val[good])
            
            # attempting to be robust here, trowing out fraction with highest abs(z)
            if(alpha>0) {
              qv <- quantile(abs(z),probs=c(alpha/2,1.0-alpha/2))
              gvi <- which(good)[which(abs(z)<qv[1] | abs(z)>qv[2])]
              good[gvi] <- F;
              if (all(!good)) {
                conv <- FALSE
                warning("no observations informative at iteration ", 
                        iter)
                break
              }
              z <- (eta - offset)[good] + (y - mu)[good]/mu.eta.val[good]
            }
            
            w <- mu.eta.val[good]*sqrt(weights[good]/variance(mu)[good])
            
            ngoodobs <- as.integer(nobs - sum(!good))
            fit <- .Fortran("dqrls", qr = x[good, ] * w, n = ngoodobs, 
                p = nvars, y = w * z, ny = 1L, tol = min(1e-07, 
                  control$epsilon/1000), coefficients = double(nvars), 
                residuals = double(ngoodobs), effects = double(ngoodobs), 
                rank = integer(1L), pivot = 1L:nvars, qraux = double(nvars), 
                work = double(2 * nvars)); # , PACKAGE = "base"
            #browser()
            if (any(!is.finite(fit$coefficients))) {
                conv <- FALSE
                warning(gettextf("non-finite coefficients at iteration %d", 
                  iter), domain = NA)
                break
            }
            if (nobs < fit$rank) 
                stop(gettextf("X matrix has rank %d, but only %d observations", 
                  fit$rank, nobs), domain = NA)
            start[fit$pivot] <- fit$coefficients
            eta <- drop(x %*% start)
            mu <- linkinv(eta <- eta + offset)
            dev <- sum(dev.resids(y, mu, weights))
            if (control$trace) 
                cat("Deviance =", dev, "Iterations -", iter, 
                  "\n")
            boundary <- FALSE
            if (!is.finite(dev)) {
                if (is.null(coefold)) 
                  stop("no valid set of coefficients has been found: please supply starting values", 
                    call. = FALSE)
                warning("step size truncated due to divergence", 
                  call. = FALSE)
                ii <- 1
                while (!is.finite(dev)) {
                  if (ii > control$maxit) 
                    stop("inner loop 1; cannot correct step size", 
                      call. = FALSE)
                  ii <- ii + 1
                  start <- (start + coefold)/2
                  eta <- drop(x %*% start)
                  mu <- linkinv(eta <- eta + offset)
                  dev <- sum(dev.resids(y, mu, weights))
                }
                boundary <- TRUE
                if (control$trace) 
                  cat("Step halved: new deviance =", dev, "\n")
            }
            # require deviance to go down
            if ((!is.null(coefold)) & (dev - devold)/(0.1 + abs(dev)) > 3*control$epsilon) {
              warning("step size truncated due to increasing divergence", call. = FALSE)
              ii <- 1
              while ((dev - devold)/(0.1 + abs(dev)) > 3*control$epsilon) {
                if (ii > control$maxit)   {
                  warning("inner loop 1; cannot correct step size", call. = FALSE)
                  break;
                }
                ii <- ii + 1
                start <- (start + coefold)/2
                eta <- drop(x %*% start)
                mu <- linkinv(eta <- eta + offset)
                dev <- sum(dev.resids(y, mu, weights))
              }
              boundary <- TRUE
              if (control$trace) 
                cat("Step halved: new deviance =", dev, "\n")
            }
            if (!(valideta(eta) && validmu(mu))) {
                if (is.null(coefold)) 
                  stop("no valid set of coefficients has been found: please supply starting values", 
                    call. = FALSE)
                warning("step size truncated: out of bounds", 
                  call. = FALSE)
                ii <- 1
                while (!(valideta(eta) && validmu(mu))) {
                  if (ii > control$maxit) 
                    stop("inner loop 2; cannot correct step size", 
                      call. = FALSE)
                  ii <- ii + 1
                  start <- (start + coefold)/2
                  eta <- drop(x %*% start)
                  mu <- linkinv(eta <- eta + offset)
                }
                boundary <- TRUE
                dev <- sum(dev.resids(y, mu, weights))
                if (control$trace) 
                  cat("Step halved: new deviance =", dev, "\n")
            }
            if (abs(dev - devold)/(0.1 + abs(dev)) < control$epsilon) {
                conv <- TRUE
                coef <- start
                break
            }
            
            devold <- dev
            coef <- coefold <- start
        }
        if (!conv) 
            warning("glm.fit: algorithm did not converge", call. = FALSE)
        if (boundary) 
            warning("glm.fit: algorithm stopped at boundary value", 
                call. = FALSE)
        eps <- 10 * .Machine$double.eps
        if (family$family == "binomial") {
            if (any(mu > 1 - eps) || any(mu < eps)) 
                warning("glm.fit: fitted probabilities numerically 0 or 1 occurred", 
                  call. = FALSE)
        }
        if (family$family == "poisson") {
            if (any(mu < eps)) 
                warning("glm.fit: fitted rates numerically 0 occurred", 
                  call. = FALSE)
        }
        if (fit$rank < nvars) 
            coef[fit$pivot][seq.int(fit$rank + 1, nvars)] <- NA
        xxnames <- xnames[fit$pivot]
        residuals <- (y - mu)/mu.eta(eta)
        fit$qr <- as.matrix(fit$qr)
        nr <- min(sum(good), nvars)
        if (nr < nvars) {
            Rmat <- diag(nvars)
            Rmat[1L:nr, 1L:nvars] <- fit$qr[1L:nr, 1L:nvars]
        }
        else Rmat <- fit$qr[1L:nvars, 1L:nvars]
        Rmat <- as.matrix(Rmat)
        Rmat[row(Rmat) > col(Rmat)] <- 0
        names(coef) <- xnames
        colnames(fit$qr) <- xxnames
        dimnames(Rmat) <- list(xxnames, xxnames)
    }
    names(residuals) <- ynames
    names(mu) <- ynames
    names(eta) <- ynames
    wt <- rep.int(0, nobs)
    wt[good] <- w^2
    names(wt) <- ynames
    names(weights) <- ynames
    names(y) <- ynames
    if (!EMPTY) 
        names(fit$effects) <- c(xxnames[seq_len(fit$rank)], rep.int("", 
            sum(good) - fit$rank))
    wtdmu <- if (intercept) 
        sum(weights * y)/sum(weights)
    else linkinv(offset)
    nulldev <- sum(dev.resids(y, wtdmu, weights))
    n.ok <- nobs - sum(weights == 0)
    nulldf <- n.ok - as.integer(intercept)
    rank <- if (EMPTY) 
        0
    else fit$rank
    resdf <- n.ok - rank
    aic.model <- aic(y, length(y), mu, weights, dev) + 2 * rank
    list(coefficients = coef, residuals = residuals, fitted.values = mu, 
        effects = if (!EMPTY) fit$effects, R = if (!EMPTY) Rmat, 
        rank = rank, qr = if (!EMPTY) structure(fit[c("qr", "rank", 
                       "qraux", "pivot", "tol")], class = "qr"), family = family, 
        linear.predictors = eta, deviance = dev, aic = aic.model, 
        null.deviance = nulldev, iter = iter, weights = wt, prior.weights = weights, 
        df.residual = resdf, df.null = nulldf, y = y, converged = conv, 
        boundary = boundary)
}


# copied from limma
weighted.median.scde <- function (x, w, na.rm = FALSE)
#       Weighted median
#       Gordon Smyth
#       30 June 2005
{
        if (missing(w))
                w <- rep.int(1, length(x))
        else {
                if(length(w) != length(x)) stop("'x' and 'w' must have the same length")
                if(any(is.na(w))) stop("NA weights not allowed")
                if(any(w<0)) stop("Negative weights not allowed")
        }
        if(is.integer(w))
                w <- as.numeric(w)
        if(na.rm) {
                w <- w[i <- !is.na(x)]
                x <- x[i]
        }
        if(all(w==0)) {
                warning("All weights are zero")
                return(NA)
        }
        o <- order(x)
        x <- x[o]
        w <- w[o]
        p <- cumsum(w)/sum(w)
        n <- sum(p<0.5)
        if(p[n+1] > 0.5)
                x[n+1]
        else
                (x[n+1]+x[n+2])/2
}

# FROM common.r

sn <- function(x) { names(x) <- x; return(x); }


# panel routines for pairs()

  pairs.panel.hist <- function(x, i=NULL, ...) {
    usr <- par("usr"); on.exit(par(usr))
    par(usr = c(usr[1:2], 0, 1.5) )
    h <- hist(x, plot = FALSE)
    breaks <- h$breaks; nB <- length(breaks)
    y <- h$counts; y <- y/max(y)
    rect(breaks[-nB], 0, breaks[-1], y, col="gray70", ...)
  }
  pairs.panel.cor <- function(x, y, digits=2, prefix="", cex.cor, i=NULL, j=NULL) {
    usr <- par("usr"); on.exit(par(usr))
    par(usr = c(0, 1, 0, 1))
    r <- abs(cor(x, y,method="pearson"))
    #r <- abs(cor(x, y,method="spearman"))
    txt <- format(c(r, 0.123456789), digits=digits)[1]
    txt <- paste(prefix, txt, sep="")
    if(missing(cex.cor)) cex <- 0.6/strwidth(txt)
    #text(0.5, 0.5, txt, cex = cex * r)
    text(0.5, 0.5, txt, cex = cex)
  }
  pairs.panel.scatter <- function(x,y,i=NULL, j=NULL, ...) {
    vi <- x>0 | y>0; points(x[vi],y[vi],pch=".",col=densCols(x[vi],y[vi],colramp=colorRampPalette(brewer.pal(9, "Blues")[-(1:2)])),cex=2);
  }

  pairs.panel.smoothScatter <- function(x,y, i=NULL, j=NULL, ...) { vi <- x>0 | y>0; smoothScatter(x[vi],y[vi], add=T, ...)}


# a slight modification of pairs that passes i/j indecies to the panel methods
pairs.extended <- function (x, labels, panel = points, ...,
          lower.panel = panel, upper.panel = panel,
          diag.panel = NULL, text.panel = textPanel,
          label.pos = 0.5 + has.diag/3,
          cex.labels = NULL, font.labels = 1,
          row1attop = TRUE, gap = 1)
{
    textPanel <-
        function(x = 0.5, y = 0.5, txt, cex, font)
            text(x, y, txt, cex = cex, font = font)

    localAxis <- function(side, x, y, xpd, bg, col=NULL, main, oma, ...) {
      ## Explicitly ignore any color argument passed in as
      ## it was most likely meant for the data points and
      ## not for the axis.
        if(side %%2 == 1) Axis(x, side=side, xpd=NA, ...)
        else Axis(y, side=side, xpd=NA, ...)
    }

    localPlot <- function(..., main, oma, font.main, cex.main) plot(...)
    localLowerPanel <- function(..., main, oma, font.main, cex.main)
        lower.panel(...)
    localUpperPanel <- function(..., main, oma, font.main, cex.main)
        upper.panel(...)

    localDiagPanel <- function(..., main, oma, font.main, cex.main)
        diag.panel(...)

    dots <- list(...); nmdots <- names(dots)
    if (!is.matrix(x)) {
        x <- as.data.frame(x)
        for(i in seq_along(names(x))) {
            if(is.factor(x[[i]]) || is.logical(x[[i]]))
               x[[i]] <- as.numeric(x[[i]])
            if(!is.numeric(unclass(x[[i]])))
                stop("non-numeric argument to 'pairs'")
        }
    } else if (!is.numeric(x)) stop("non-numeric argument to 'pairs'")
    panel <- match.fun(panel)
    if((has.lower <- !is.null(lower.panel)) && !missing(lower.panel))
        lower.panel <- match.fun(lower.panel)
    if((has.upper <- !is.null(upper.panel)) && !missing(upper.panel))
        upper.panel <- match.fun(upper.panel)
    if((has.diag  <- !is.null( diag.panel)) && !missing( diag.panel))
        diag.panel <- match.fun( diag.panel)

    if(row1attop) {
        tmp <- lower.panel; lower.panel <- upper.panel; upper.panel <- tmp
        tmp <- has.lower; has.lower <- has.upper; has.upper <- tmp
    }

    nc <- ncol(x)
    if (nc < 2) stop("only one column in the argument to 'pairs'")
    has.labs <- TRUE
    if (missing(labels)) {
        labels <- colnames(x)
        if (is.null(labels)) labels <- paste("var", 1L:nc)
    }
    else if(is.null(labels)) has.labs <- FALSE
    oma <- if("oma" %in% nmdots) dots$oma else NULL
    main <- if("main" %in% nmdots) dots$main else NULL
    if (is.null(oma)) {
        oma <- c(4, 4, 4, 4)
        if (!is.null(main)) oma[3L] <- 6
    }
    opar <- par(mfrow = c(nc, nc), mar = rep.int(gap/2, 4), oma = oma)
    on.exit(par(opar))

    for (i in if(row1attop) 1L:nc else nc:1L)
        for (j in 1L:nc) {
            localPlot(x[, j], x[, i], xlab = "", ylab = "",
                      axes = FALSE, type = "n", ...)
            if(i == j || (i < j && has.lower) || (i > j && has.upper) ) {
                box()
                if(i == 1  && (!(j %% 2) || !has.upper || !has.lower ))
                    localAxis(1 + 2*row1attop, x[, j], x[, i], ...)
                if(i == nc && (  j %% 2  || !has.upper || !has.lower ))
                    localAxis(3 - 2*row1attop, x[, j], x[, i], ...)
                if(j == 1  && (!(i %% 2) || !has.upper || !has.lower ))
                    localAxis(2, x[, j], x[, i], ...)
                if(j == nc && (  i %% 2  || !has.upper || !has.lower ))
                    localAxis(4, x[, j], x[, i], ...)
                mfg <- par("mfg")
                if(i == j) {
                    if (has.diag) localDiagPanel(as.vector(x[, i]), i=i, ...)
                    if (has.labs) {
                        par(usr = c(0, 1, 0, 1))
                        if(is.null(cex.labels)) {
                            l.wid <- strwidth(labels, "user")
                            cex.labels <- max(0.8, min(2, .9 / max(l.wid)))
                        }
                        text.panel(0.5, label.pos, labels[i],
                                   cex = cex.labels, font = font.labels)
                    }
                } else if(i < j)
                    localLowerPanel(as.vector(x[, j]), as.vector(x[, i]), i=i,j=j, ...)
                else
                    localUpperPanel(as.vector(x[, j]), as.vector(x[, i]), i=i,j=j, ...)
                if (any(par("mfg") != mfg))
                    stop("the 'panel' function made a new plot")
            } else par(new = FALSE)

        }
    if (!is.null(main)) {
        font.main <- if("font.main" %in% nmdots) dots$font.main else par("font.main")
        cex.main <- if("cex.main" %in% nmdots) dots$cex.main else par("cex.main")
        mtext(main, 3, 3, TRUE, 0.5, cex = cex.main, font = font.main)
    }
    invisible(NULL)
}


# given a set of pdfs (columns), calculate summary statis (mle, 95% CI, Z-score deviations from 0)  
quick.distribution.summary <- function(s.bdiffp) {
  diffv <- as.numeric(colnames(s.bdiffp))
  dq <- t(apply(s.bdiffp,1,function(p) { mle <- which.max(p); p <- cumsum(p); return(diffv[c(lb=max(c(1,which(p<0.025))),mle,min(c(length(p),which(p>(1-0.025)))))]) }))/log10(2); colnames(dq) <- c("lb","mle","ub");
  cq <- rep(0,nrow(dq)); 0; cq[dq[,1]>0] <- dq[dq[,1]>0,1]; cq[dq[,3]<0] <- dq[dq[,3]<0,3];
  z <- get.ratio.posterior.Z.score(s.bdiffp);
  za <- sign(z)*qnorm(p.adjust(pnorm(abs(z),lower.tail=F),method="BH"),lower.tail=F)
  data.frame(dq,"ce"=as.numeric(cq),"Z"=as.numeric(z),"cZ"=as.numeric(za));
}


# rook class for browsing differential expression results

ViewDiff <- setRefClass(
  'ViewDiff',
  fields = c('gt','models','counts','prior','groups','batch','geneLookupURL'),
  methods = list(

    initialize = function(results,models,counts,prior,groups=NULL,batch=NULL,geneLookupURL=NULL) {
      if(!is.null(results$results)) {
        gt <<- results$results;
      } else {
        gt <<- results;
      }
      # add raw names if this wasn't a batch-corrected sample
      if("mle" %in% colnames(gt)) {
        colnames(gt) <<- paste(colnames(gt),"raw",sep="_")
      }
      if(!is.null(results$batch.adjusted)) {
        df <- results$batch.adjusted; colnames(df) <- paste(colnames(df),"cor",sep="_")
        gt <<- cbind(gt,df);
      }
      if(!is.null(results$batch.effect)) {
        df <- results$batch.effect; colnames(df) <- paste(colnames(df),"bat",sep="_")
        gt <<- cbind(gt,df);
      }
      colnames(gt) <<- tolower(colnames(gt))

      # append expression levels to the results
      if(!is.null(results$joint.posteriors)) {
        gt$lev1 <<- log10(as.numeric(colnames(results$joint.posteriors[[1]]))[max.col(results$joint.posteriors[[1]])]+1)
        gt$lev2 <<- log10(as.numeric(colnames(results$joint.posteriors[[2]]))[max.col(results$joint.posteriors[[2]])]+1)
      }
      gt$gene <<- rownames(gt);
      gt <<- data.frame(gt);

      # guess gene lookup for common cases
      if(is.null(geneLookupURL)) {
        # human
        if( any(grepl("ENSG\\d+",gt$gene[1])) || any(c("CCLU1","C22orf45") %in% gt$gene)) {
          geneLookupURL <<- "http://useast.ensembl.org/Homo_sapiens/Gene/Summary?g={0}";
        } else if( any(grepl("ENSMUSG\\d+",gt$gene[1]))) {
          geneLookupURL <<- "http://useast.ensembl.org/Mus_musculus/Gene/Summary?g={0}";
        } else if( any(c("Foxp2","Sept1","Lrrc34") %in% gt$gene)) {
          # mouse MGI
          geneLookupURL <<- "http://www.informatics.jax.org/searchtool/Search.do?query={0}"
        } else if( any(grepl("FBgn\\d+",gt$gene[1])) || any(c("CG3680","CG8290") %in% gt$gene)) {
          # flybase
          geneLookupURL <<- "http://flybase.org/cgi-bin/uniq.html?db=fbgn&GeneSearch={0}&context={1}&species=Dmel&cs=yes&caller=genejump"
        } else {
          # default, forward to ensemble search
          geneLookupURL <<- "http://useast.ensembl.org/Multi/Search/Results?q={0};site=ensembl"
        }
      } else {
        geneLookupURL <<- geneLookupURL;
      }
      

      
      gt <<- gt[gt$z_raw!="NA",]
      gt <<- gt[!is.na(gt$z_raw),]
      

      models <<- models;
      counts <<- counts;
      prior <<- prior;
      if(is.null(groups)) { # recover groups from models
        groups <<- as.factor(attr(models,"groups"));
        if(is.null(groups)) stop("ERROR: groups factor is not provided, and models structure is lacking groups attribute");
        names(groups) <<- rownames(models)
      } else {
        groups <<- groups;
      }
      if(length(levels(groups))!=2) {
        stop(paste("ERROR: wrong number of levels in the grouping factor (",paste(levels(groups),collapse=" "),"), but must be two.",sep=""))
      }
      
      batch <<- batch;
      callSuper()
    },
    call = function(env){
      path <- env[['PATH_INFO']]
      req <- Request$new(env)
      res <- Response$new()

      switch(path,
             # INDEX
             '/index.html'={
               body <- paste('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <title>SCDE: ',paste(levels(groups),collapse=" vs. "),'</title>
    <!-- ExtJS -->
    <link rel="stylesheet" type="text/css" href="http://pklab.med.harvard.edu/sde/ext-4.2.1.883/resources/css/ext-all.css" />
    
    <!-- Shared -->
    <link rel="stylesheet" type="text/css" href="http://pklab.med.harvard.edu/sde/ext-4.2.1.883/examples/shared/example.css" />

    <link rel="stylesheet" type="text/css" href="http://pklab.med.harvard.edu/sde/additional.css" />
    <!-- GC -->

    <style type="text/css">
        .x-panel-framed {
            padding: 0;
        }
    </style>
    <script type="text/javascript" src="http://pklab.med.harvard.edu/sde/ext-4.2.1.883/ext-all.js"></script>

    <script type="text/javascript">var geneLookupURL = "',geneLookupURL,'"</script>
    <script type="text/javascript" src="http://pklab.med.harvard.edu/sde/viewembed.js"></script>
    
</head>
<body style="margin-top:0;padding-top:10px;">
	<div id="example-grid"></div>
  </body>
</html>
',sep="");
               res$header('"Content-Type": "text/html"')
               res$write(body);               
             },
             # GENE TABLE
             '/genetable.json'={
               lgt <- gt;
               if(!is.null(req$params()$filter)) {
                 fl <- rjson::fromJSON(URLdecode(req$params()$filter));
                 for( fil in fl) {
                   lgt <- lgt[grep(fil$value,lgt[,fil$property],perl=T,ignore.case=T),]
                 }
               }
               start <- ifelse(is.null(req$params()$start),1,as.integer(req$params()$start)+1)
               limit <- ifelse(is.null(req$params()$limit),1000,as.integer(req$params()$limit))
               dir <- ifelse(is.null(req$params()$dir),"DESC",req$params()$dir)
               trows <- nrow(lgt);  
               if(trows>0) {
                 if(!is.null(req$params()$sort)) {
                   if(req$params()$sort %in% colnames(lgt)) {
                     lgt <- lgt[order(lgt[,req$params()$sort],decreasing=(dir=="DESC")),];
                   }
                 } else { # default sort
                   if(is.null(lgt$z_cor)) { lgt <- lgt[order(abs(lgt$z_raw),decreasing=T),] } else { lgt <- lgt[order(abs(lgt$z_cor),decreasing=T),] }
                 }
               }
               lgt <- format(lgt[min(start,nrow(lgt)):min((start+limit),nrow(lgt)),],nsmall=2,digits=2)
               ol <- apply(lgt,1,function(x) as.list(x))
               names(ol) <- NULL
               s <- rjson::toJSON(list(totalCount=trows,genes=ol))
               res$header('"Content-Type": "application/json"')
               if(!is.null(req$params()$callback)) {
                 res$write(paste(req$params()$callback,"(",s,")",sep=""))
               } else {
                 res$write(s)
               }
               
             },
             # POSTERIOR PLOT
             '/posterior.png'={
               gene <- ifelse(is.null(req$params()$gene),sample(gt$gene),req$params()$gene)
               bootstrap <- ifelse(is.null(req$params()$bootstrap),TRUE,req$params()$bootstrap=="T")
               show.individual.posteriors <- ifelse(is.null(req$params()$show.individual.posteriors),TRUE,req$params()$show.individual.posteriors=="true")

               t <- tempfile();
               #require(Cairo)
               CairoPNG(filename=t,width=350,height=560)
               scde.test.gene.expression.difference(gene=gene,models=models,counts=counts,groups=groups,prior=prior,batch=batch,ratio.range=c(-10,10),show.individual.posteriors=show.individual.posteriors,verbose=F);
               dev.off();
               res$header('Content-type','image/png')
               res$body <- t; names(res$body) <- 'file';
             },
             # GENE EXPRESSION LEVELS
             '/elevels.html'={
               geneName <- ifelse(is.null(req$params()$geneName),gt$gene[[1]],req$params()$geneName)
               gc <- counts[rownames(counts)==geneName,,drop=F]
               fpm <- exp(scde.expression.magnitude(models,counts=gc));
               df <- rbind(FPM=gc,level=fpm)
               df <- round(df,2)
               # order columns according to groups
               df <- df[,unlist(tapply(1:ncol(df),groups,I))]
               cell.col <- rep(c("#E9A994","#66CCFF"),as.integer(table(groups)))
               
               render.row <- function(nam,val,col) {
                 paste("<tr>","<th>",nam,"</th>",paste("<td bgcolor=",col,">",val,"</td>",sep="",collapse=" "),"</tr>",sep="")
               }
               
               sh <- paste("<tr>",paste("<th>",c(" ",colnames(df)),"</th>",sep="",collapse=" "),"</tr>")
               #sb <- paste(render.row("cells",colnames(df),cell.col),render.row("FPKM",df[1,],cell.col),render.row("mode",df[2,],cell.col),collapse="\n")
               sb <- paste(render.row("counts",df[1,],cell.col),render.row("FPM",df[2,],cell.col),collapse="\n")
               res$header('"Content-Type": "text/html"')
               res$write(paste("<table id=\"elevels\">",sh,sb,"</table>"))
             },
             {
               res$write('default')
             }
             )
      res$finish();
    }
    )
  )
