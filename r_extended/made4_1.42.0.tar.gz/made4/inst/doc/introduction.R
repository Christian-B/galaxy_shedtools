### R code from vignette source 'introduction.rnw'

###################################################
### code chunk number 1: setup
###################################################
library(ade4)
library(made4)
library(scatterplot3d)
oldopt <- options(digits=3)
options(width=60)
on.exit( {options(oldopt)} )


###################################################
### code chunk number 2: loadlibs
###################################################
 library(made4)
 library(ade4)


###################################################
### code chunk number 3: loadkhan
###################################################
 data(khan)


###################################################
### code chunk number 4: khandata
###################################################
names(khan)
k.data<-khan$train
k.class<-khan$train.classes


###################################################
### code chunk number 5: overview.extra
###################################################
overview(k.data)


###################################################
### code chunk number 6: overviewKhan
###################################################
overview(k.data, labels=k.class)


###################################################
### code chunk number 7: overviewKhan2
###################################################
overview(k.data, classvec=k.class, labels=k.class)


###################################################
### code chunk number 8: ord.coa
###################################################
k.coa<- ord(k.data, type="coa")


###################################################
### code chunk number 9: output.coa
###################################################
names(k.coa)
summary(k.coa$ord)


###################################################
### code chunk number 10: see.classes
###################################################
k.class


###################################################
### code chunk number 11: plotcoa
###################################################
plot(k.coa, classvec=k.class, arraycol=c("red", "blue", "yellow", "green"), genecol="grey3")


###################################################
### code chunk number 12: plotarrays
###################################################
plotgenes(k.coa)  


###################################################
### code chunk number 13: plotarrays
###################################################
plotarrays(k.coa, arraylabels=k.class)


###################################################
### code chunk number 14: plotarays2
###################################################
k.coa2<-ord(k.data, classvec=k.class)
plot(k.coa2)


###################################################
### code chunk number 15: plotgenes
###################################################
plotgenes(k.coa, n=5, col="red")


###################################################
### code chunk number 16: plotgenescmd
###################################################

gene.symbs<- khan$annotation$Symbol 
plotgenes(k.coa, n=10, col="red", genelabels=gene.symbs)


###################################################
### code chunk number 17: plotgenes2
###################################################
plotgenes(k.coa, n=10, col="red", genelabels=gene.symbs)


###################################################
### code chunk number 18: topgenes
###################################################
topgenes(k.coa, axis = 1, n=5)   


###################################################
### code chunk number 19: topgenes2
###################################################
topgenes(k.coa, labels=gene.symbs, end="neg") 


###################################################
### code chunk number 20: do3d
###################################################
do3d(k.coa$ord$co, classvec=k.class, cex.symbols=3)
html3D(k.coa$ord$co, k.class, writehtml=TRUE)


###################################################
### code chunk number 21: bga
###################################################
k.bga<-bga(k.data, type="coa", classvec=k.class)


###################################################
### code chunk number 22: BGAplot
###################################################
plot(k.bga, genelabels=gene.symbs) # Use the gene symbols earlier


###################################################
### code chunk number 23: between.graph
###################################################
between.graph(k.bga, ax=1)  # Show the separation on the first axes(ax)


###################################################
### code chunk number 24: CIA
###################################################
# Example data are "G1_Ross_1375.txt" and "G5_Affy_1517.txt"
data(NCI60)
coin <- cia(NCI60$Ross, NCI60$Affy)
names(coin)
coin$coinertia$RV


###################################################
### code chunk number 25: CIAplot
###################################################
plot(coin, classvec=NCI60$classes[,2], clab=0, cpoint=3)


